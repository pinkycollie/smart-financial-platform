"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Menu, Bell, User, Search, Video, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAccessibility } from "@/components/accessibility/accessibility-provider"
import { useVisualAlert } from "@/components/accessibility/visual-alert-provider"

export function Header() {
  const [showMobileMenu, setShowMobileMenu] = useState(false)
  const { preferences, updatePreference } = useAccessibility()
  const { showAlert } = useVisualAlert()

  const handleNotificationClick = () => {
    showAlert("You have 3 new notifications", "info")
  }

  const handleInterpreterRequest = () => {
    showAlert("Connecting to an interpreter...", "info")
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setShowMobileMenu(!showMobileMenu)}>
            <Menu className="h-5 w-5" />
          </Button>
          <Link href="/" className="flex items-center gap-2">
            <Image src="/abstract-geometric-logo.png" alt="Logo" width={32} height={32} />
            <span className="font-bold text-xl hidden md:inline-block">Deaf-First Tax</span>
          </Link>
        </div>

        <div className="hidden md:flex items-center gap-6">
          <div className="relative w-64">
            <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search..." className="pl-8" />
          </div>
          <nav className="flex items-center gap-4">
            <Button variant="ghost" asChild>
              <Link href="/dashboard">Dashboard</Link>
            </Button>
            <Button variant="ghost" asChild>
              <Link href="/tax-forms">Tax Forms</Link>
            </Button>
            <Button variant="ghost" asChild>
              <Link href="/advisors">Find Advisors</Link>
            </Button>
            <Button variant="ghost" asChild>
              <Link href="/resources">Resources</Link>
            </Button>
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" className="relative" onClick={handleInterpreterRequest}>
            <Video className="h-5 w-5 text-primary" />
            <span className="sr-only">Request Interpreter</span>
          </Button>
          <Button variant="outline" size="icon" className="relative" onClick={handleNotificationClick}>
            <Bell className="h-5 w-5" />
            <span className="sr-only">Notifications</span>
            <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0">3</Badge>
          </Button>
          <Button variant="outline" size="icon">
            <MessageSquare className="h-5 w-5" />
            <span className="sr-only">Messages</span>
          </Button>
          <Avatar>
            <AvatarImage src="/vibrant-street-market.png" alt="User" />
            <AvatarFallback>
              <User className="h-5 w-5" />
            </AvatarFallback>
          </Avatar>
        </div>
      </div>

      {/* Visual accessibility indicator */}
      {preferences.visualAlerts && <div className="h-1 bg-primary w-full" aria-hidden="true"></div>}

      {/* Mobile menu */}
      {showMobileMenu && (
        <div className="md:hidden border-t p-4 bg-background">
          <div className="flex flex-col space-y-3">
            <Link href="/dashboard" className="px-2 py-1 hover:bg-muted rounded-md">
              Dashboard
            </Link>
            <Link href="/tax-forms" className="px-2 py-1 hover:bg-muted rounded-md">
              Tax Forms
            </Link>
            <Link href="/advisors" className="px-2 py-1 hover:bg-muted rounded-md">
              Find Advisors
            </Link>
            <Link href="/resources" className="px-2 py-1 hover:bg-muted rounded-md">
              Resources
            </Link>
          </div>
        </div>
      )}
    </header>
  )
}
