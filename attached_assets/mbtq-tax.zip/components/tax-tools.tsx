import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function TaxTools() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {tools.map((tool, index) => (
        <div key={index} className="rounded-lg border p-3">
          <h3 className="font-medium">{tool.name}</h3>
          <p className="text-xs text-muted-foreground mt-1 mb-3">{tool.description}</p>
          <Button variant="outline" size="sm" className="w-full">
            <span>Launch</span>
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      ))}
    </div>
  )
}

const tools = [
  {
    name: "Tax Research",
    description: "Access comprehensive federal, state, and international tax research",
  },
  {
    name: "Fixed Assets",
    description: "Cloud-based depreciation modeling with secure client data access",
  },
  {
    name: "Income Tax Planner",
    description: "Project taxes up to 20 years with side-by-side comparisons",
  },
  {
    name: "Tax Provision",
    description: "Simplified ASC 740 compliance designed for provision professionals",
  },
]
