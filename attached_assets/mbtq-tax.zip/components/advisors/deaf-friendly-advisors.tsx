"use client"

import { useState } from "react"
import { useVisualAlert } from "@/components/accessibility/visual-alert-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, MapPin, Video, MessageSquare, Filter } from "lucide-react"

interface Advisor {
  id: string
  name: string
  title: string
  company: string
  location: string
  distance: number
  rating: number
  reviews: number
  image: string
  specialties: string[]
  languages: string[]
  availability: {
    nextAvailable: string
    slots: { date: string; time: string }[]
  }
  deafFriendly: boolean
  signLanguageFluent: boolean
  videoCallAvailable: boolean
}

const mockAdvisors: Advisor[] = [
  {
    id: "adv-1",
    name: "Emily Chen, CPA",
    title: "Senior Tax Advisor",
    company: "Inclusive Tax Solutions",
    location: "San Francisco, CA",
    distance: 2.4,
    rating: 4.9,
    reviews: 127,
    image: "/diverse-group-city.png",
    specialties: ["Individual Tax", "Small Business", "Deaf Community"],
    languages: ["ASL", "English", "Mandarin"],
    availability: {
      nextAvailable: "Today",
      slots: [
        { date: "Today", time: "3:00 PM" },
        { date: "Today", time: "4:30 PM" },
        { date: "Tomorrow", time: "10:00 AM" },
      ],
    },
    deafFriendly: true,
    signLanguageFluent: true,
    videoCallAvailable: true,
  },
  {
    id: "adv-2",
    name: "Marcus Johnson",
    title: "Tax Specialist",
    company: "Deaf-First Financial",
    location: "Oakland, CA",
    distance: 5.7,
    rating: 4.8,
    reviews: 93,
    image: "/diverse-group-city.png",
    specialties: ["Tax Planning", "Retirement", "Education Credits"],
    languages: ["ASL", "English"],
    availability: {
      nextAvailable: "Tomorrow",
      slots: [
        { date: "Tomorrow", time: "11:30 AM" },
        { date: "Tomorrow", time: "2:00 PM" },
        { date: "Friday", time: "1:00 PM" },
      ],
    },
    deafFriendly: true,
    signLanguageFluent: true,
    videoCallAvailable: true,
  },
  {
    id: "adv-3",
    name: "Sophia Rodriguez",
    title: "Tax Attorney",
    company: "Access Tax Legal",
    location: "San Jose, CA",
    distance: 12.3,
    rating: 4.7,
    reviews: 78,
    image: "/diverse-group-city.png",
    specialties: ["Tax Law", "IRS Disputes", "Business Tax"],
    languages: ["English", "Spanish"],
    availability: {
      nextAvailable: "Friday",
      slots: [
        { date: "Friday", time: "9:00 AM" },
        { date: "Friday", time: "3:30 PM" },
        { date: "Monday", time: "10:00 AM" },
      ],
    },
    deafFriendly: true,
    signLanguageFluent: false,
    videoCallAvailable: true,
  },
  {
    id: "adv-4",
    name: "David Kim",
    title: "Financial Advisor",
    company: "Accessible Wealth",
    location: "Palo Alto, CA",
    distance: 18.5,
    rating: 4.9,
    reviews: 112,
    image: "/diverse-group-city.png",
    specialties: ["Investment Tax", "Estate Planning", "Retirement"],
    languages: ["ASL", "English", "Korean"],
    availability: {
      nextAvailable: "Monday",
      slots: [
        { date: "Monday", time: "11:00 AM" },
        { date: "Monday", time: "2:30 PM" },
        { date: "Tuesday", time: "9:30 AM" },
      ],
    },
    deafFriendly: true,
    signLanguageFluent: true,
    videoCallAvailable: true,
  },
]

export function DeafFriendlyAdvisors() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSpecialty, setSelectedSpecialty] = useState<string | null>(null)
  const [onlySignLanguageFluent, setOnlySignLanguageFluent] = useState(true)
  const [selectedAdvisor, setSelectedAdvisor] = useState<Advisor | null>(null)
  const [selectedSlot, setSelectedSlot] = useState<{ date: string; time: string } | null>(null)
  
  const { showAlert } = useVisualAlert()
  
  // Filter advisors based on search and filters
  const filteredAdvisors = mockAdvisors
    .filter((advisor) => {
      // Filter by search term
      if (
        searchTerm &&
        !advisor.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !advisor.location.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !advisor.specialties.some((s) => s.toLowerCase().includes(searchTerm.toLowerCase()))
      ) {
        return false
      }
      
      // Filter by specialty
      if (selectedSpecialty && !advisor.specialties.includes(selectedSpecialty)) {
        return false
      }
      
      // Filter by sign language fluency
      if (onlySignLanguageFluent && !advisor.signLanguageFluent) {
        return false
      }
      
      return true
    })
    .sort((a, b) => a.distance - b.distance)
  
  // Get all unique specialties
  const allSpecialties = Array.from(
    new Set(mockAdvisors.flatMap((advisor) => advisor.specialties))
  ).sort()
  
  const handleBookAppointment = () => {
    if (!selectedAdvisor || !selectedSlot) {
      showAlert("Please select an advisor and appointment time", "warning")
      return
    }
    
    showAlert(
      `Appointment booked with ${selectedAdvisor.name} on ${selectedSlot.date} at ${selectedSlot.time}`,
      "success"
    )
    
    // Reset selection
    setSelectedSlot(null)
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Find Deaf-Friendly Tax Advisors</CardTitle>
        <CardDescription>
          Connect with tax professionals who are fluent in sign language or experienced in working
          with deaf clients
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="search">
          <TabsList className="grid grid-cols-2">
            <TabsTrigger value="search">Search</TabsTrigger>
            <TabsTrigger value="appointment" disabled={!selectedAdvisor}>
              Book Appointment
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="search">
            <div className="space-y-4">
              {/* Search and filters */}
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <Label htmlFor="search" className="sr-only">
                    Search
                  </Label>
                  <Input
                    id="search"
                    placeholder="Search by name, location, or specialty"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex gap-2">
                  <div className="w-48">
                    <Label htmlFor="specialty" className="sr-only">
                      Specialty
                    </Label>
                    <select
                      id="specialty"
                      className="w-full h-10 px-3 rounded-md border"
                      value={selectedSpecialty || ""}
                      onChange={(e) => setSelectedSpecialty(e.target.value || null)}
                    >
                      <option value="">All Specialties</option>
                      {allSpecialties.map((specialty) => (
                        <option key={specialty} value={specialty}>
                          {specialty}
                        </option>
                      ))}
                    </select>
                  </div>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Filter className="h-4 w-4" />
                    Filters
                  </Button>
                </div>
              </div>
              
              {/* Sign language filter */}
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="sign-language"
                  checked={onlySignLanguageFluent}
                  onChange={(e) => setOnlySignLanguageFluent(e.target.checked)}
                  className="h-4 w-4 rounded border-gray-300"
                />
                <Label htmlFor="sign-language">Only show advisors fluent in sign language</Label>
              </div>
              
              {/* Results */}
              <div className="space-y-4 mt-6">
                {filteredAdvisors.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No advisors found matching your criteria</p>
                    <Button
                      variant="link"
                      onClick={() => {
                        setSearchTerm("")
                        setSelectedSpecialty(null)
                        setOnlySignLanguageFluent(false)
                      }}
                    >
                      Clear filters
                    </Button>
                  </div>
                ) : (
                  filteredAdvisors.map((advisor) => (
                    <Card key={advisor.id} className="overflow-hidden">
                      <div className="flex flex-col md:flex-row">
                        <div className="p-4 md:p-6 flex-1">
                          <div className="flex items-start gap-4">
                            <Avatar className="h-16 w-16">
                              <AvatarImage src={advisor.image} alt={advisor.name} />
                              <AvatarFallback>
                                {advisor.name
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center justify-between">
                                <h3 className="font-medium text-lg">{advisor.name}</h3>
                                <div className="flex items-center">
                                  <Star className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                                  <span className="ml-1 font-medium">{advisor.rating}</span>
                                  <span className="text-muted-foreground text-sm ml-1">
                                    ({advisor.reviews})
                                  </span>
                                </div>
                              </div>
                              <p className="text-muted-foreground">
                                {advisor.title} at {advisor.company}
                              </p>
                              <div className="flex items-center mt-1 text-sm text-muted-foreground">
                                <MapPin className="h-3 w-3 mr-1" />
                                {advisor.location} ({advisor.distance} miles away)
                              </div>
                              
                              <div className="flex flex-wrap gap-1 mt-2">
                                {advisor.signLanguageFluent && (
                                  <Badge variant="secondary">ASL Fluent</Badge>
                                )}
                                {advisor.videoCallAvailable && (
                                  <Badge variant="outline">Video Calls</Badge>
                                )}
                                {advisor.specialties.slice(0, 2).map((specialty) => (
                                  <Badge key={specialty} variant="outline">
                                    {specialty}
                                  </Badge>
                                ))}
                                {advisor.specialties.length > 2 && (
                                  <Badge variant="outline">+{advisor.specialties.length - 2}</Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          
                          <div className="mt-4">
                            <h4 className="text-sm font-medium mb-1">Languages</h4>
                            <div className="flex flex-wrap gap-1">
                              {advisor.languages.map((language) => (
                                <Badge key={language} variant="secondary">
                                  {language}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="border-t md:border-t-0 md:border-l p-4 md:w-64 flex flex-col">
                          <p className="text-sm font-medium">Next Available</p>
                          <p className="text-lg">{advisor.availability.nextAvailable}</p>
                          <div className="mt-2 space-y-2">
                            {advisor.availability.slots.slice(0, 2).map((slot, i) => (
                              <div key={i} className="text-sm">
                                {slot.date}: {slot.time}
                              </div>
                            ))}
                          </div>
                          <div className="mt-auto pt-4 flex flex-col gap-2">
                            <Button
                              onClick={() => {
                                setSelectedAdvisor(advisor)
                                setSelectedSlot(null)
                              }}
                            >
                              Book Appointment
                            </Button>
                            <div className="grid grid-cols-2 gap-2">
                              <Button variant="outline" size="sm">
                                <Video className="h-4 w-4 mr-1" />
                                Video Call
                              </Button>
                              <Button variant="outline" size="sm">
                                <MessageSquare className="h-4 w-4 mr-1" />
                                Message
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  ))
                )}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="appointment">
            {selectedAdvisor && (
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSelectedAdvisor(null)}
                  >
                    ← Back to search
                  </Button>
                  <h3 className="font-medium">Book an appointment with {selectedAdvisor.name}</h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium mb-3">Select a date & time</h4>
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-2">
                        {["Today", "Tomorrow", "Friday", "Monday", "Tuesday", "Wednesday"].map(
                          (date) => (
                            <Button
                              key={date}
                              variant="outline"
                              className={
                                selectedAdvisor.availability.slots.some((s) => s.date === date)
                                  ? ""
                                  : "opacity-50 cursor-not-allowed"
                              }
                              disabled={
                                !selectedAdvisor.availability.slots.some((s) => s.date === date)
                              }
                            >
                              {date}
                            </Button>
                          )
                        )}
                      </div>
                      
                      <div className="border rounded-md p-4">
                        <h5 className="text-sm font-medium mb-3">Available times</h5>
                        <div className="grid grid-cols-3 gap-2">
                          \
