"use client"

import { useState } from "react"
import Image from "next/image"
import {
  BarChart3,
  Calendar,
  FileText,
  FolderOpen,
  MessageSquare,
  PieChart,
  Settings,
  Clock,
  Bell,
  Search,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function DashboardPreview() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="w-full max-w-6xl mx-auto rounded-xl overflow-hidden border shadow-lg bg-card">
      <div className="flex h-[600px]">
        {/* Sidebar */}
        <div className="hidden md:flex w-64 flex-col border-r bg-muted/30">
          <div className="p-4 flex items-center gap-2 border-b">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mbtqtaxlogo.jpg-ZhKwAyivF5WW6WaO3UvnS3wUHTxjat.jpeg"
              alt="MBTQ Tax Logo"
              width={32}
              height={32}
              className="h-8 w-auto"
            />
            <span className="font-bold">MBTQ Tax</span>
          </div>

          <div className="flex-1 py-4">
            <nav className="px-2 space-y-1">
              <Button
                variant={activeTab === "overview" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("overview")}
              >
                <PieChart className="mr-2 h-4 w-4" />
                Overview
              </Button>
              <Button
                variant={activeTab === "returns" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("returns")}
              >
                <FileText className="mr-2 h-4 w-4" />
                Tax Returns
              </Button>
              <Button
                variant={activeTab === "planning" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("planning")}
              >
                <BarChart3 className="mr-2 h-4 w-4" />
                Tax Planning
              </Button>
              <Button
                variant={activeTab === "documents" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("documents")}
              >
                <FolderOpen className="mr-2 h-4 w-4" />
                Documents
              </Button>
              <Button
                variant={activeTab === "calendar" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("calendar")}
              >
                <Calendar className="mr-2 h-4 w-4" />
                Calendar
              </Button>
              <Button
                variant={activeTab === "messages" ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveTab("messages")}
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                Messages
                <Badge className="ml-auto" variant="secondary">
                  3
                </Badge>
              </Button>
            </nav>
          </div>

          <div className="p-4 border-t">
            <Button variant="ghost" className="w-full justify-start">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          {/* Header */}
          <header className="h-14 border-b flex items-center justify-between px-4">
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
              </Button>
              <div className="relative w-64">
                <Search className="absolute left-2 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Search..." className="pl-8" />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon">
                <Bell className="h-5 w-5" />
              </Button>
              <Avatar>
                <AvatarImage src="/placeholder.svg?height=32&width=32" />
                <AvatarFallback>JD</AvatarFallback>
              </Avatar>
            </div>
          </header>

          {/* Dashboard Content */}
          <div className="flex-1 overflow-auto p-4">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold">Welcome back, Jane</h1>
                <p className="text-muted-foreground">Here's what's happening with your taxes</p>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Last updated: Today, 2:30 PM</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Federal Return</p>
                      <p className="text-2xl font-bold">$2,450</p>
                      <p className="text-xs text-muted-foreground">Estimated refund</p>
                    </div>
                    <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">State Return</p>
                      <p className="text-2xl font-bold">$850</p>
                      <p className="text-xs text-muted-foreground">Estimated refund</p>
                    </div>
                    <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Filing Deadline</p>
                      <p className="text-2xl font-bold">Apr 15</p>
                      <p className="text-xs text-muted-foreground">45 days remaining</p>
                    </div>
                    <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-primary" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Tabs defaultValue="overview" className="mb-6">
              <TabsList>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="deductions">Deductions</TabsTrigger>
                <TabsTrigger value="income">Income</TabsTrigger>
                <TabsTrigger value="planning">Planning</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card className="col-span-1 md:col-span-2">
                    <CardContent className="p-4">
                      <h3 className="font-medium mb-2">Tax Summary</h3>
                      <div className="h-[200px] bg-muted/50 rounded-md flex items-center justify-center">
                        <span className="text-muted-foreground">Tax Summary Chart</span>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <h3 className="font-medium mb-2">Recent Documents</h3>
                      <ul className="space-y-2">
                        <li className="flex items-center justify-between">
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span>W-2 Form.pdf</span>
                          </div>
                          <span className="text-xs text-muted-foreground">Yesterday</span>
                        </li>
                        <li className="flex items-center justify-between">
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span>1099-INT.pdf</span>
                          </div>
                          <span className="text-xs text-muted-foreground">3 days ago</span>
                        </li>
                        <li className="flex items-center justify-between">
                          <div className="flex items-center">
                            <FileText className="h-4 w-4 mr-2 text-muted-foreground" />
                            <span>Mortgage Interest.pdf</span>
                          </div>
                          <span className="text-xs text-muted-foreground">1 week ago</span>
                        </li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="p-4">
                      <h3 className="font-medium mb-2">Tax Advisor</h3>
                      <div className="flex items-center gap-3 mb-3">
                        <Avatar>
                          <AvatarImage src="/placeholder.svg?height=40&width=40" />
                          <AvatarFallback>SA</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">Sarah Anderson</p>
                          <p className="text-xs text-muted-foreground">Tax Specialist</p>
                        </div>
                      </div>
                      <Button variant="outline" className="w-full">
                        Schedule Meeting
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="deductions" className="mt-4">
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-medium mb-2">Deductions Preview</h3>
                    <div className="h-[300px] bg-muted/50 rounded-md flex items-center justify-center">
                      <span className="text-muted-foreground">Deductions Content</span>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="income" className="mt-4">
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-medium mb-2">Income Preview</h3>
                    <div className="h-[300px] bg-muted/50 rounded-md flex items-center justify-center">
                      <span className="text-muted-foreground">Income Content</span>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="planning" className="mt-4">
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-medium mb-2">Tax Planning Preview</h3>
                    <div className="h-[300px] bg-muted/50 rounded-md flex items-center justify-center">
                      <span className="text-muted-foreground">Tax Planning Content</span>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <div className="text-xs text-center text-muted-foreground mt-4">
              <p className="font-semibold">Powered by Bloomberg Tax</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function Menu(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="4" x2="20" y1="12" y2="12" />
      <line x1="4" x2="20" y1="6" y2="6" />
      <line x1="4" x2="20" y1="18" y2="18" />
    </svg>
  )
}
