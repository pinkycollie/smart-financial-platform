import { Info } from "lucide-react"

export function BloombergTaxBanner() {
  return (
    <div className="mb-6 rounded-lg border bg-muted/30 p-4">
      <div className="flex items-center gap-4">
        <div className="flex-shrink-0">
          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
            <Info className="h-6 w-6 text-primary" />
          </div>
        </div>
        <div className="flex-1">
          <h3 className="font-semibold flex items-center">
            <span>Powered by</span>
            <span className="ml-2 font-bold text-primary">Bloomberg Tax</span>
          </h3>
          <p className="text-sm text-muted-foreground">
            MBTQ Tax leverages Bloomberg Tax's industry-leading research and technology solutions to provide accurate,
            efficient, and timely tax services.
          </p>
        </div>
      </div>
    </div>
  )
}
