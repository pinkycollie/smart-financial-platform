"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { useAccessibility } from "@/components/accessibility/accessibility-provider"
import { useVisualAlert } from "@/components/accessibility/visual-alert-provider"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Video, VideoOff, Mic, MicOff, Phone, MessageSquare, Users } from "lucide-react"

type InterpreterService = "internal" | "external" | "community"

interface Interpreter {
  id: string
  name: string
  languages: string[]
  availability: "available" | "busy" | "offline"
  rating: number
  specialties: string[]
}

const mockInterpreters: Interpreter[] = [
  {
    id: "int-1",
    name: "Sarah Johnson",
    languages: ["ASL", "English"],
    availability: "available",
    rating: 4.9,
    specialties: ["Tax", "Finance", "Legal"],
  },
  {
    id: "int-2",
    name: "Michael Chen",
    languages: ["ASL", "English", "Mandarin"],
    availability: "available",
    rating: 4.8,
    specialties: ["Tax", "Business"],
  },
  {
    id: "int-3",
    name: "Jessica Rodriguez",
    languages: ["ASL", "English", "Spanish"],
    availability: "busy",
    rating: 4.7,
    specialties: ["Tax", "Real Estate"],
  },
  {
    id: "int-4",
    name: "David Kim",
    languages: ["ASL", "English", "Korean"],
    availability: "offline",
    rating: 4.9,
    specialties: ["Tax", "Investment"],
  },
]

export function InterpreterConnect() {
  const [service, setService] = useState<InterpreterService>("internal")
  const [selectedInterpreter, setSelectedInterpreter] = useState<Interpreter | null>(null)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isConnected, setIsConnected] = useState(false)
  const [videoEnabled, setVideoEnabled] = useState(true)
  const [audioEnabled, setAudioEnabled] = useState(true)
  const [showChat, setShowChat] = useState(false)
  const [messages, setMessages] = useState<{ sender: string; text: string; time: string }[]>([])
  const [newMessage, setNewMessage] = useState("")

  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)

  const { preferences } = useAccessibility()
  const { showAlert } = useVisualAlert()

  // Filter interpreters based on availability
  const availableInterpreters = mockInterpreters.filter((interpreter) => interpreter.availability === "available")

  // Handle connection to interpreter
  const handleConnect = () => {
    if (!selectedInterpreter) {
      showAlert("Please select an interpreter first", "warning")
      return
    }

    setIsConnecting(true)

    // Simulate connection delay
    setTimeout(() => {
      setIsConnecting(false)
      setIsConnected(true)
      showAlert(`Connected with ${selectedInterpreter.name}`, "success")

      // Simulate receiving a message
      setTimeout(() => {
        const newMsg = {
          sender: selectedInterpreter.name,
          text: "Hello! How can I help you with your tax questions today?",
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        }
        setMessages((prev) => [...prev, newMsg])
        showAlert("New message from interpreter", "info")
      }, 2000)
    }, 1500)
  }

  // Handle disconnection
  const handleDisconnect = () => {
    setIsConnected(false)
    showAlert("Call ended", "info")
  }

  // Handle sending a message
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    const message = {
      sender: "You",
      text: newMessage,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages((prev) => [...prev, message])
    setNewMessage("")

    // Simulate reply
    if (isConnected && selectedInterpreter) {
      setTimeout(() => {
        const reply = {
          sender: selectedInterpreter.name,
          text: "I understand your question. Let me explain that tax concept in more detail...",
          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        }
        setMessages((prev) => [...prev, reply])
      }, 3000)
    }
  }

  // Request camera/mic access when component mounts
  useEffect(() => {
    if (localVideoRef.current) {
      navigator.mediaDevices
        .getUserMedia({ video: true, audio: true })
        .then((stream) => {
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = stream
          }
        })
        .catch((err) => {
          console.error("Error accessing media devices:", err)
          showAlert("Could not access camera or microphone", "error")
        })
    }

    return () => {
      // Clean up media streams
      if (localVideoRef.current && localVideoRef.current.srcObject) {
        const tracks = (localVideoRef.current.srcObject as MediaStream).getTracks()
        tracks.forEach((track) => track.stop())
      }
    }
  }, [])

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Connect with an Interpreter</CardTitle>
        <CardDescription>
          Get real-time assistance from a sign language interpreter specialized in tax matters
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Video area */}
          <div className="space-y-4">
            <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
              {isConnected && selectedInterpreter ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <Users className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                    <p className="font-medium">{selectedInterpreter.name}</p>
                    <p className="text-sm text-muted-foreground">Connected</p>
                  </div>
                </div>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-muted-foreground">Remote video will appear here</p>
                </div>
              )}

              {/* Local video preview */}
              <div className="absolute bottom-4 right-4 w-1/3 aspect-video bg-black rounded overflow-hidden shadow-lg">
                <video
                  ref={localVideoRef}
                  autoPlay
                  muted
                  playsInline
                  className={`w-full h-full object-cover ${!videoEnabled ? "hidden" : ""}`}
                />
                {!videoEnabled && (
                  <div className="absolute inset-0 flex items-center justify-center bg-muted">
                    <VideoOff className="h-6 w-6 text-muted-foreground" />
                  </div>
                )}
              </div>
            </div>

            {/* Video controls */}
            <div className="flex justify-center space-x-4">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setVideoEnabled(!videoEnabled)}
                className={!videoEnabled ? "bg-muted" : ""}
              >
                {videoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setAudioEnabled(!audioEnabled)}
                className={!audioEnabled ? "bg-muted" : ""}
              >
                {audioEnabled ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
              </Button>
              {isConnected ? (
                <Button variant="destructive" size="icon" onClick={handleDisconnect}>
                  <Phone className="h-5 w-5" />
                </Button>
              ) : (
                <Button
                  variant="default"
                  size="icon"
                  onClick={handleConnect}
                  disabled={!selectedInterpreter || isConnecting}
                >
                  <Phone className="h-5 w-5" />
                </Button>
              )}
              <Button
                variant="outline"
                size="icon"
                onClick={() => setShowChat(!showChat)}
                className={showChat ? "bg-muted" : ""}
              >
                <MessageSquare className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Interpreter selection or chat */}
          <div>
            {showChat ? (
              <div className="h-[300px] flex flex-col border rounded-md">
                <div className="p-3 border-b bg-muted">
                  <h3 className="font-medium">Chat</h3>
                </div>
                <div className="flex-1 overflow-y-auto p-3 space-y-3">
                  {messages.length === 0 ? (
                    <p className="text-center text-muted-foreground text-sm py-8">No messages yet</p>
                  ) : (
                    messages.map((msg, i) => (
                      <div key={i} className={`flex ${msg.sender === "You" ? "justify-end" : "justify-start"}`}>
                        <div
                          className={`max-w-[80%] rounded-lg p-3 ${
                            msg.sender === "You" ? "bg-primary text-primary-foreground" : "bg-muted"
                          }`}
                        >
                          <p className="text-sm font-medium">{msg.sender}</p>
                          <p>{msg.text}</p>
                          <p className="text-xs opacity-70 text-right mt-1">{msg.time}</p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
                <form onSubmit={handleSendMessage} className="border-t p-3 flex">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="flex-1 bg-transparent focus:outline-none"
                    disabled={!isConnected}
                  />
                  <Button type="submit" size="sm" disabled={!isConnected || !newMessage.trim()}>
                    Send
                  </Button>
                </form>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="service-type">Interpreter Service</Label>
                  <Select value={service} onValueChange={(value) => setService(value as InterpreterService)}>
                    <SelectTrigger id="service-type">
                      <SelectValue placeholder="Select service" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="internal">Internal Interpreters</SelectItem>
                      <SelectItem value="external">External Service</SelectItem>
                      <SelectItem value="community">Community Volunteers</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="interpreter">Select an Interpreter</Label>
                  <Select
                    value={selectedInterpreter?.id || ""}
                    onValueChange={(value) => {
                      const interpreter = mockInterpreters.find((i) => i.id === value)
                      setSelectedInterpreter(interpreter || null)
                    }}
                  >
                    <SelectTrigger id="interpreter">
                      <SelectValue placeholder="Choose an interpreter" />
                    </SelectTrigger>
                    <SelectContent>
                      {availableInterpreters.length > 0 ? (
                        availableInterpreters.map((interpreter) => (
                          <SelectItem key={interpreter.id} value={interpreter.id}>
                            {interpreter.name} - {interpreter.languages.join(", ")}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="none" disabled>
                          No interpreters available
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                </div>

                {selectedInterpreter && (
                  <div className="border rounded-md p-4">
                    <h3 className="font-medium mb-2">{selectedInterpreter.name}</h3>
                    <div className="text-sm space-y-1">
                      <p>
                        <span className="font-medium">Languages:</span> {selectedInterpreter.languages.join(", ")}
                      </p>
                      <p>
                        <span className="font-medium">Specialties:</span> {selectedInterpreter.specialties.join(", ")}
                      </p>
                      <p>
                        <span className="font-medium">Rating:</span> {selectedInterpreter.rating}/5.0
                      </p>
                      <p>
                        <span className="font-medium">Status:</span>{" "}
                        <span className="inline-flex items-center">
                          <span
                            className={`h-2 w-2 rounded-full mr-1 ${
                              selectedInterpreter.availability === "available"
                                ? "bg-green-500"
                                : selectedInterpreter.availability === "busy"
                                  ? "bg-yellow-500"
                                  : "bg-gray-500"
                            }`}
                          />
                          {selectedInterpreter.availability}
                        </span>
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <Switch id="schedule" />
                  <Label htmlFor="schedule">Schedule for later</Label>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <p className="text-sm text-muted-foreground">
          {isConnected
            ? "Connected. Interpreter services are provided free of charge."
            : "Interpreter services are available 24/7 and provided free of charge."}
        </p>
        {!isConnected && !showChat && (
          <Button onClick={handleConnect} disabled={!selectedInterpreter || isConnecting}>
            {isConnecting ? "Connecting..." : "Connect Now"}
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}
