import { Circle } from "lucide-react"

export function RecentActivity() {
  return (
    <div className="space-y-4">
      {activities.map((activity, index) => (
        <div key={index} className="flex items-start gap-4">
          <div className="relative mt-1">
            <Circle className="h-2 w-2 fill-current" />
            {index !== activities.length - 1 && (
              <div className="absolute bottom-0 left-1/2 top-2 w-px -translate-x-1/2 bg-border" />
            )}
          </div>
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{activity.title}</p>
            <p className="text-xs text-muted-foreground">{activity.description}</p>
            <p className="text-xs text-muted-foreground">{activity.time}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

const activities = [
  {
    title: "Tax Return Completed",
    description: "Completed annual tax return for Alex T.",
    time: "2 hours ago",
  },
  {
    title: "New Client Added",
    description: "Added Disability Advocates Network as a new client",
    time: "Yesterday at 2:30 PM",
  },
  {
    title: "Research Completed",
    description: "Completed research on tax credits for accessibility modifications",
    time: "Yesterday at 10:15 AM",
  },
  {
    title: "Client Meeting",
    description: "Met with Jamie L. to discuss tax planning strategies",
    time: "2 days ago",
  },
]
