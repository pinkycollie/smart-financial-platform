"use client"

import type React from "react"

import { useState } from "react"
import { useAccessibility } from "@/components/accessibility/accessibility-provider"
import { useVisualAlert } from "@/components/accessibility/visual-alert-provider"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Checkbox } from "@/components/ui/checkbox"
import { Info, HelpCircle, Play, Pause } from "lucide-react"

interface FormField {
  id: string
  label: string
  type: "text" | "number" | "checkbox" | "select"
  required: boolean
  helpText?: string
  videoExplanation?: string
  options?: { value: string; label: string }[]
}

interface FormSection {
  id: string
  title: string
  description?: string
  fields: FormField[]
  videoOverview?: string
}

interface VideoEnrichedFormProps {
  title: string
  description?: string
  sections: FormSection[]
  onSubmit: (data: Record<string, any>) => void
}

export function VideoEnrichedForm({ title, description, sections, onSubmit }: VideoEnrichedFormProps) {
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [activeSection, setActiveSection] = useState(sections[0].id)
  const [playingVideo, setPlayingVideo] = useState<string | null>(null)
  const [showCaptions, setShowCaptions] = useState(true)

  const { preferences } = useAccessibility()
  const { showAlert } = useVisualAlert()

  const handleInputChange = (fieldId: string, value: any) => {
    setFormData((prev) => ({ ...prev, [fieldId]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    // Validate required fields
    const currentSection = sections.find((section) => section.id === activeSection)
    if (!currentSection) return

    const missingFields = currentSection.fields
      .filter((field) => field.required && !formData[field.id])
      .map((field) => field.label)

    if (missingFields.length > 0) {
      showAlert(`Please fill in the following fields: ${missingFields.join(", ")}`, "warning")
      return
    }

    // If this is the last section, submit the form
    if (sections[sections.length - 1].id === activeSection) {
      onSubmit(formData)
      showAlert("Form submitted successfully!", "success")
    } else {
      // Move to the next section
      const currentIndex = sections.findIndex((section) => section.id === activeSection)
      setActiveSection(sections[currentIndex + 1].id)
      showAlert(`Moving to ${sections[currentIndex + 1].title}`, "info")
    }
  }

  const toggleVideo = (videoId: string) => {
    if (playingVideo === videoId) {
      setPlayingVideo(null)
    } else {
      setPlayingVideo(videoId)
    }
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent>
        <Tabs value={activeSection} onValueChange={setActiveSection}>
          <TabsList className="grid" style={{ gridTemplateColumns: `repeat(${sections.length}, 1fr)` }}>
            {sections.map((section) => (
              <TabsTrigger key={section.id} value={section.id}>
                {section.title}
              </TabsTrigger>
            ))}
          </TabsList>

          {sections.map((section) => (
            <TabsContent key={section.id} value={section.id}>
              <form onSubmit={handleSubmit}>
                <div className="space-y-6">
                  {section.videoOverview && (
                    <div className="relative rounded-md overflow-hidden">
                      <div className="aspect-video bg-muted flex items-center justify-center">
                        {playingVideo === `section-${section.id}` ? (
                          <>
                            <video src={section.videoOverview} controls autoPlay className="w-full h-full" />
                            {showCaptions && (
                              <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 text-white p-2 text-center">
                                This is a sample caption for the video explanation.
                              </div>
                            )}
                          </>
                        ) : (
                          <div className="text-center">
                            <Play className="h-12 w-12 mx-auto mb-2 text-muted-foreground" />
                            <p className="font-medium">Watch Video Overview</p>
                            <p className="text-sm text-muted-foreground">
                              Learn more about this section with ASL explanation
                            </p>
                          </div>
                        )}
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => toggleVideo(`section-${section.id}`)}
                      >
                        {playingVideo === `section-${section.id}` ? (
                          <Pause className="h-4 w-4 mr-1" />
                        ) : (
                          <Play className="h-4 w-4 mr-1" />
                        )}
                        {playingVideo === `section-${section.id}` ? "Pause" : "Play"}
                      </Button>
                    </div>
                  )}

                  <div className="space-y-4">
                    {section.fields.map((field) => (
                      <div key={field.id} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <Label htmlFor={field.id}>
                            {field.label}
                            {field.required && <span className="text-red-500 ml-1">*</span>}
                          </Label>

                          {field.videoExplanation && (
                            <Button type="button" variant="ghost" size="sm" onClick={() => toggleVideo(field.id)}>
                              <HelpCircle className="h-4 w-4 mr-1" />
                              Explain
                            </Button>
                          )}
                        </div>

                        {field.videoExplanation && playingVideo === field.id && (
                          <div className="relative rounded-md overflow-hidden mb-2">
                            <div className="aspect-video bg-muted">
                              <video src={field.videoExplanation} controls autoPlay className="w-full h-full" />
                              {showCaptions && (
                                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 text-white p-2 text-center">
                                  This is a sample caption explaining {field.label}.
                                </div>
                              )}
                            </div>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="absolute top-2 right-2"
                              onClick={() => toggleVideo(field.id)}
                            >
                              <Pause className="h-4 w-4 mr-1" />
                              Close
                            </Button>
                          </div>
                        )}

                        {field.type === "checkbox" ? (
                          <div className="flex items-center space-x-2">
                            <Checkbox
                              id={field.id}
                              checked={!!formData[field.id]}
                              onCheckedChange={(checked) => handleInputChange(field.id, checked)}
                            />
                            <label htmlFor={field.id} className="text-sm text-muted-foreground">
                              {field.helpText}
                            </label>
                          </div>
                        ) : field.type === "select" ? (
                          <select
                            id={field.id}
                            value={formData[field.id] || ""}
                            onChange={(e) => handleInputChange(field.id, e.target.value)}
                            className="w-full p-2 border rounded-md"
                            required={field.required}
                          >
                            <option value="">Select an option</option>
                            {field.options?.map((option) => (
                              <option key={option.value} value={option.value}>
                                {option.label}
                              </option>
                            ))}
                          </select>
                        ) : (
                          <Input
                            id={field.id}
                            type={field.type}
                            value={formData[field.id] || ""}
                            onChange={(e) => handleInputChange(field.id, e.target.value)}
                            required={field.required}
                          />
                        )}

                        {field.helpText && !field.videoExplanation && (
                          <p className="text-sm text-muted-foreground flex items-center">
                            <Info className="h-3 w-3 mr-1" />
                            {field.helpText}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 flex justify-between">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      const currentIndex = sections.findIndex((s) => s.id === activeSection)
                      if (currentIndex > 0) {
                        setActiveSection(sections[currentIndex - 1].id)
                      }
                    }}
                    disabled={sections[0].id === activeSection}
                  >
                    Previous
                  </Button>
                  <Button type="submit">
                    {sections[sections.length - 1].id === activeSection ? "Submit" : "Next"}
                  </Button>
                </div>
              </form>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="show-captions"
            checked={showCaptions}
            onCheckedChange={(checked) => setShowCaptions(!!checked)}
          />
          <Label htmlFor="show-captions">Show captions</Label>
        </div>
        <p className="text-sm text-muted-foreground">
          Need help?{" "}
          <a href="#" className="text-primary hover:underline">
            Contact support
          </a>
        </p>
      </CardFooter>
    </Card>
  )
}
