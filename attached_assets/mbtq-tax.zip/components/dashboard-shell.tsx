import type { ReactNode } from "react"
import Link from "next/link"
import Image from "next/image"
import { LayoutDashboard, Users, FileText, Calculator, Calendar, Settings, HelpCircle, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"

interface DashboardShellProps {
  children: ReactNode
}

export function DashboardShell({ children }: DashboardShellProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mbtqtaxlogo.jpg-ZhKwAyivF5WW6WaO3UvnS3wUHTxjat.jpeg"
              alt="MBTQ Tax Logo"
              width={32}
              height={32}
              className="h-8 w-auto"
            />
            <span className="text-xl font-bold">MBTQ Tax</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/dashboard">Dashboard</Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/clients">Clients</Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/tools">Tax Tools</Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/insurance">Insurance</Link>
            </Button>
            <Button variant="ghost" size="sm" asChild>
              <Link href="/360">360 Magicians</Link>
            </Button>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon">
              <HelpCircle className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Settings className="h-5 w-5" />
            </Button>
            <Button variant="outline" size="sm">
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>
      <div className="flex flex-1">
        <aside className="hidden md:flex w-64 flex-col border-r bg-muted/40 px-4 py-6">
          <nav className="flex flex-col gap-2">
            <Button variant="ghost" className="justify-start" asChild>
              <Link href="/dashboard" className="flex items-center gap-2">
                <LayoutDashboard className="h-5 w-5" />
                Dashboard
              </Link>
            </Button>
            <Button variant="ghost" className="justify-start" asChild>
              <Link href="/clients" className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Clients
              </Link>
            </Button>
            <Button variant="ghost" className="justify-start" asChild>
              <Link href="/returns" className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Tax Returns
              </Link>
            </Button>
            <Button variant="ghost" className="justify-start" asChild>
              <Link href="/tools" className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Tax Tools
              </Link>
            </Button>
            <Button variant="ghost" className="justify-start" asChild>
              <Link href="/calendar" className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Calendar
              </Link>
            </Button>
          </nav>
          <div className="mt-auto">
            <div className="rounded-lg border bg-card p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="h-2 w-2 rounded-full bg-green-500"></div>
                <span className="text-sm font-medium">Bloomberg Tax</span>
              </div>
              <p className="text-xs text-muted-foreground">All tax tools are up-to-date with the latest regulations.</p>
            </div>
          </div>
        </aside>
        <main className="flex-1 overflow-auto p-6">{children}</main>
      </div>
    </div>
  )
}
