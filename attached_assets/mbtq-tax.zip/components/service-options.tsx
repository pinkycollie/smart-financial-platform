"use client"

import { useState } from "react"
import { Check, ArrowRight, UserCog, Users, Share2 } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { useVisualAlert } from "@/components/accessibility/visual-alert-provider"

export function ServiceOptions() {
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const { showAlert } = useVisualAlert()

  const handleOptionSelect = (option: string) => {
    setSelectedOption(option)
    showAlert(`You selected the ${option} option`, "success")
  }

  const serviceOptions = [
    {
      id: "full-service",
      title: "Full Service",
      description: "Let our experts handle your taxes completely",
      price: "$199/year",
      features: [
        "Complete tax preparation by experts",
        "Video calls with ASL-fluent tax advisors",
        "Document review and optimization",
        "Year-round tax support",
        "Audit protection included",
        "Maximum refund guarantee",
      ],
      icon: <Users className="h-6 w-6 text-primary" />,
      badge: "Most Popular",
    },
    {
      id: "self-service",
      title: "DIY Management",
      description: "Prepare your taxes yourself with our accessible tools",
      price: "$79/year",
      features: [
        "User-friendly accessible interface",
        "ASL video guides for all tax concepts",
        "3D visualizations of tax scenarios",
        "Unlimited state and federal returns",
        "Document upload and organization",
        "Basic audit support",
      ],
      icon: <UserCog className="h-6 w-6 text-primary" />,
      badge: null,
    },
    {
      id: "advisor-share",
      title: "Advisor Share",
      description: "Share with your existing tax advisor",
      price: "$49/year",
      features: [
        "Secure document sharing with your advisor",
        "Accessible explanations of tax concepts",
        "Collaborative workspace with your advisor",
        "ASL interpretation for advisor meetings",
        "Tax document organization",
        "Year-round document storage",
      ],
      icon: <Share2 className="h-6 w-6 text-primary" />,
      badge: "Best Value",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold tracking-tight">Choose Your Service Option</h2>
        <p className="text-muted-foreground mt-2">Select the service level that best fits your needs and preferences</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {serviceOptions.map((option) => (
          <Card
            key={option.id}
            className={`relative overflow-hidden transition-all ${
              selectedOption === option.id ? "border-primary shadow-md" : "hover:border-primary/50 hover:shadow-sm"
            }`}
          >
            {option.badge && (
              <div className="absolute top-0 right-0">
                <Badge className="rounded-tl-none rounded-br-none">{option.badge}</Badge>
              </div>
            )}
            <CardHeader>
              <div className="mb-4">{option.icon}</div>
              <CardTitle>{option.title}</CardTitle>
              <CardDescription>{option.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold mb-4">{option.price}</div>
              <ul className="space-y-2">
                {option.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-primary shrink-0 mr-2" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button
                className="w-full"
                variant={selectedOption === option.id ? "default" : "outline"}
                onClick={() => handleOptionSelect(option.id)}
              >
                {selectedOption === option.id ? "Selected" : "Select"}{" "}
                {selectedOption !== option.id && <ArrowRight className="ml-2 h-4 w-4" />}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      {selectedOption && (
        <div className="flex justify-center mt-8">
          <Button size="lg">
            Continue with {serviceOptions.find((o) => o.id === selectedOption)?.title}{" "}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
}
