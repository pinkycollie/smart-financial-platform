import { Check } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface PricingCardProps {
  title: string
  price: string
  originalPrice?: string
  description: string
  features: string[]
  buttonText: string
  buttonVariant: "default" | "outline"
  highlighted?: boolean
  badge?: string
}

export function PricingCard({
  title,
  price,
  originalPrice,
  description,
  features,
  buttonText,
  buttonVariant,
  highlighted = false,
  badge,
}: PricingCardProps) {
  return (
    <Card className={cn("flex flex-col h-full transition-all", highlighted && "border-primary shadow-lg scale-105")}>
      <CardHeader>
        {badge && (
          <Badge className="w-fit mb-2" variant="secondary">
            {badge}
          </Badge>
        )}
        <CardTitle>{title}</CardTitle>
        <div className="mt-4 flex items-baseline">
          <span className="text-5xl font-extrabold">{price}</span>
          <span className="ml-1 text-xl font-medium text-muted-foreground">/month</span>
          {originalPrice && <span className="ml-2 text-sm line-through text-muted-foreground">{originalPrice}</span>}
        </div>
        <CardDescription className="mt-4">{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <ul className="space-y-3">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="h-5 w-5 text-primary shrink-0 mr-2" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button variant={buttonVariant} className="w-full">
          {buttonText}
        </Button>
      </CardFooter>
    </Card>
  )
}
