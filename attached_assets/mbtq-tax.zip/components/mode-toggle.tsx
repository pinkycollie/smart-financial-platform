"use client"

import { useState, useEffect } from "react"
import { Check, ChevronDown } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

const modes = [
  {
    id: "default",
    name: "Default",
    className: "",
  },
  {
    id: "lgbtqia",
    name: "LGBTQIA",
    className: "lgbtqia",
  },
  {
    id: "deaf",
    name: "Deaf & HH",
    className: "deaf",
  },
  {
    id: "disabilities",
    name: "Disabilities",
    className: "disabilities",
  },
]

export function ModeToggle() {
  const [currentMode, setCurrentMode] = useState(modes[0])

  useEffect(() => {
    // Remove all theme classes
    document.documentElement.classList.remove(...modes.map((mode) => mode.className).filter(Boolean))

    // Add the current theme class if it exists
    if (currentMode.className) {
      document.documentElement.classList.add(currentMode.className)
    }
  }, [currentMode])

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="flex items-center gap-2">
          <span>{currentMode.name} Mode</span>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {modes.map((mode) => (
          <DropdownMenuItem
            key={mode.id}
            onClick={() => setCurrentMode(mode)}
            className={cn("flex items-center gap-2", currentMode.id === mode.id && "bg-accent")}
          >
            <span>{mode.name}</span>
            {currentMode.id === mode.id && <Check className="h-4 w-4 ml-auto" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
