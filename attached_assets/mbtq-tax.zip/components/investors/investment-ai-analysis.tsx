"use client"

import { useState } from "react"
import { Bot, RefreshCw, Download, ChevronDown, ChevronUp } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

export function InvestmentAIAnalysis() {
  const [isGenerating, setIsGenerating] = useState(false)
  const [isGenerated, setIsGenerated] = useState(true) // Set to true to show mock data
  const [expandedSections, setExpandedSections] = useState<string[]>(["summary"])

  const toggleSection = (section: string) => {
    if (expandedSections.includes(section)) {
      setExpandedSections(expandedSections.filter((s) => s !== section))
    } else {
      setExpandedSections([...expandedSections, section])
    }
  }

  const handleGenerateAnalysis = () => {
    setIsGenerating(true)

    // Simulate AI analysis generation
    setTimeout(() => {
      setIsGenerating(false)
      setIsGenerated(true)
    }, 3000)
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            AI Investment Analysis
          </CardTitle>
          <CardDescription>
            Our AI analyzes market trends, competitive landscape, and project metrics to provide investment insights
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!isGenerated ? (
            <div className="flex flex-col items-center justify-center py-12">
              {isGenerating ? (
                <>
                  <RefreshCw className="h-12 w-12 text-primary animate-spin mb-4" />
                  <h3 className="text-lg font-medium mb-2">Generating Analysis</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Our AI is analyzing market data and project metrics...
                  </p>
                  <Progress value={65} className="w-64 h-2" />
                </>
              ) : (
                <>
                  <Bot className="h-12 w-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">Generate AI Analysis</h3>
                  <p className="text-sm text-muted-foreground mb-6 text-center max-w-md">
                    Our AI will analyze current market conditions, project metrics, and competitive landscape to provide
                    investment insights.
                  </p>
                  <Button onClick={handleGenerateAnalysis}>Generate Analysis</Button>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-6">
              {/* Analysis Summary */}
              <div className="border rounded-md overflow-hidden">
                <div
                  className="flex items-center justify-between p-4 cursor-pointer bg-muted/50"
                  onClick={() => toggleSection("summary")}
                >
                  <h3 className="font-medium">Executive Summary</h3>
                  {expandedSections.includes("summary") ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </div>

                {expandedSections.includes("summary") && (
                  <div className="p-4 border-t">
                    <div className="flex items-center gap-2 mb-4">
                      <Badge className="bg-green-500">Recommended</Badge>
                      <Badge variant="outline">High Potential</Badge>
                      <Badge variant="outline">Moderate Risk</Badge>
                    </div>

                    <p className="mb-4">
                      The Deaf-First Tax AI Platform represents a compelling investment opportunity targeting an
                      underserved market with significant growth potential. The platform's unique focus on accessibility
                      for the deaf community creates a defensible market position with limited direct competition.
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div className="p-3 bg-green-50 rounded-md">
                        <div className="text-sm text-muted-foreground">Potential ROI (5yr)</div>
                        <div className="text-xl font-bold">4.2x - 5.8x</div>
                      </div>
                      <div className="p-3 bg-amber-50 rounded-md">
                        <div className="text-sm text-muted-foreground">Risk Assessment</div>
                        <div className="text-xl font-bold">Moderate</div>
                      </div>
                      <div className="p-3 bg-blue-50 rounded-md">
                        <div className="text-sm text-muted-foreground">Market Fit Score</div>
                        <div className="text-xl font-bold">8.4/10</div>
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground">
                      Based on current traction, market size, and execution capability, our AI model predicts a
                      successful market entry with potential for significant returns. The specialized nature of the
                      platform creates barriers to entry for competitors.
                    </p>
                  </div>
                )}
              </div>

              {/* Market Analysis */}
              <div className="border rounded-md overflow-hidden">
                <div
                  className="flex items-center justify-between p-4 cursor-pointer bg-muted/50"
                  onClick={() => toggleSection("market")}
                >
                  <h3 className="font-medium">Market Analysis</h3>
                  {expandedSections.includes("market") ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </div>

                {expandedSections.includes("market") && (
                  <div className="p-4 border-t">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2">Market Opportunity</h4>
                        <p className="text-sm">
                          The platform addresses a significant gap in the tax preparation market for the deaf community.
                          With approximately 11.5 million deaf and hard of hearing individuals in the US and limited
                          accessible tax solutions, the addressable market is substantial and largely untapped.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2">Competitive Analysis</h4>
                        <p className="text-sm">
                          Current competitors fall into three categories: traditional tax services with limited
                          accessibility features, specialized accountants with high costs, and non-profit services with
                          limited scope. None offer a comprehensive, accessible, AI-powered solution specifically
                          designed for the deaf community.
                        </p>
                      </div>

                      <div>
                        <h4 className="font-medium mb-2">Growth Potential</h4>
                        <p className="text-sm">
                          The market for accessible financial services is growing at 18% annually, driven by increasing
                          awareness of accessibility needs and regulatory requirements. The platform is well-positioned
                          to capture this growth with its specialized focus.
                        </p>
                      </div>

                      <div className="p-3 bg-muted rounded-md">
                        <h4 className="font-medium mb-2">AI Market Prediction</h4>
                        <p className="text-sm">
                          Based on current trends and market analysis, our AI predicts the platform could capture 15-20%
                          of the accessible tax preparation market within 5 years, representing approximately $180-240
                          million in annual revenue potential.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Risk Assessment */}
              <div className="border rounded-md overflow-hidden">
                <div
                  className="flex items-center justify-between p-4 cursor-pointer bg-muted/50"
                  onClick={() => toggleSection("risk")}
                >
                  <h3 className="font-medium">Risk Assessment</h3>
                  {expandedSections.includes("risk") ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </div>

                {expandedSections.includes("risk") && (
                  <div className="p-4 border-t">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span>Execution Risk</span>
                        <div className="flex items-center">
                          <span className="font-medium mr-2">Moderate</span>
                          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-amber-500 w-3/5" />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Market Adoption Risk</span>
                        <div className="flex items-center">
                          <span className="font-medium mr-2">Low</span>
                          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-green-500 w-2/5" />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Technology Risk</span>
                        <div className="flex items-center">
                          <span className="font-medium mr-2">Moderate</span>
                          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-amber-500 w-3/5" />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Competitive Risk</span>
                        <div className="flex items-center">
                          <span className="font-medium mr-2">Low</span>
                          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-green-500 w-2/5" />
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span>Regulatory Risk</span>
                        <div className="flex items-center">
                          <span className="font-medium mr-2">Low-Moderate</span>
                          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-amber-500 w-1/2" />
                          </div>
                        </div>
                      </div>

                      <div className="p-3 bg-muted rounded-md mt-4">
                        <h4 className="font-medium mb-2">Risk Mitigation Strategies</h4>
                        <ul className="text-sm space-y-1 list-disc pl-4">
                          <li>Phased development approach to manage execution risk</li>
                          <li>Early partnerships with deaf community organizations to drive adoption</li>
                          <li>Hybrid approach combining AI with human experts for accuracy</li>
                          <li>Ongoing compliance monitoring and regular security audits</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Investment Recommendation */}
              <div className="border rounded-md overflow-hidden">
                <div
                  className="flex items-center justify-between p-4 cursor-pointer bg-muted/50"
                  onClick={() => toggleSection("recommendation")}
                >
                  <h3 className="font-medium">Investment Recommendation</h3>
                  {expandedSections.includes("recommendation") ? (
                    <ChevronUp className="h-5 w-5" />
                  ) : (
                    <ChevronDown className="h-5 w-5" />
                  )}
                </div>

                {expandedSections.includes("recommendation") && (
                  <div className="p-4 border-t">
                    <div className="flex items-center gap-2 mb-4">
                      <Badge className="bg-green-500">Buy</Badge>
                      <Badge variant="outline">Long-term Hold</Badge>
                      <Badge variant="outline">Growth Investment</Badge>
                    </div>

                    <p className="mb-4">
                      Based on our comprehensive analysis, the Deaf-First Tax AI Platform represents a strong investment
                      opportunity with significant growth potential and a unique market position. The combination of
                      addressing an underserved market, leveraging AI technology, and focusing on accessibility creates
                      a compelling value proposition.
                    </p>

                    <div className="space-y-2 mb-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Confidence Score</span>
                        <span className="font-medium">85%</span>
                      </div>
                      <Progress value={85} className="h-2" />

                      <div className="flex items-center justify-between mt-4">
                        <span className="text-sm">Recommended Investment Horizon</span>
                        <span className="font-medium">3-5 years</span>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm">Expected Annual Return</span>
                        <span className="font-medium">25-35%</span>
                      </div>
                    </div>

                    <div className="p-3 bg-green-50 rounded-md">
                      <h4 className="font-medium mb-2">Key Investment Thesis</h4>
                      <ul className="text-sm space-y-1 list-disc pl-4">
                        <li>Addressing an underserved market with significant size and growth potential</li>
                        <li>Unique focus on accessibility creates barriers to entry and competitive advantage</li>
                        <li>Strong team with domain expertise in both tax and accessibility</li>
                        <li>Scalable technology platform with potential for expansion to other financial services</li>
                        <li>Growing regulatory emphasis on accessibility creates tailwinds for adoption</li>
                      </ul>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={handleGenerateAnalysis} disabled={isGenerating}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isGenerating ? "animate-spin" : ""}`} />
            Refresh Analysis
          </Button>
          <Button disabled={!isGenerated}>
            <Download className="h-4 w-4 mr-2" />
            Download Full Report
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
