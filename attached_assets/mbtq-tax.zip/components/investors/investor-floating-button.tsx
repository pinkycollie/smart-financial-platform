"use client"

import { useState } from "react"
import { TrendingUp } from "lucide-react"
import { Button } from "@/components/ui/button"
import { InvestorModal } from "@/components/investors/investor-modal"

export function InvestorFloatingButton() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 rounded-full shadow-lg z-50 flex items-center gap-2"
      >
        <TrendingUp className="h-5 w-5" />
        <span>Investors</span>
      </Button>
      <InvestorModal open={isOpen} onOpenChange={setIsOpen} />
    </>
  )
}
