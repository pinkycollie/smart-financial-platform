"use client"

import { useState } from "react"
import { TrendingUp, DollarSign, Users, BarChart3, Calendar, CheckCircle, Clock, ArrowRight } from "lucide-react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { InvestmentAIAnalysis } from "@/components/investors/investment-ai-analysis"

interface InvestorModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function InvestorModal({ open, onOpenChange }: InvestorModalProps) {
  const [activeTab, setActiveTab] = useState("overview")

  // Project funding stats
  const fundingStats = {
    raised: 850000,
    goal: 2000000,
    investors: 12,
    minInvestment: 15000,
    equity: 0.5, // 0.5% equity for $15k
    valuation: 3000000,
    nextMilestone: "Beta Launch",
    completionPercentage: 42,
  }

  // Development milestones
  const milestones = [
    {
      name: "Concept & Design",
      status: "completed",
      date: "Q1 2023",
    },
    {
      name: "Alpha Development",
      status: "completed",
      date: "Q3 2023",
    },
    {
      name: "Beta Launch",
      status: "in-progress",
      date: "Q2 2024",
    },
    {
      name: "Public Release",
      status: "upcoming",
      date: "Q4 2024",
    },
    {
      name: "Market Expansion",
      status: "upcoming",
      date: "Q2 2025",
    },
  ]

  // Market statistics
  const marketStats = [
    {
      label: "Addressable Market",
      value: "11.5M",
      description: "Deaf and hard of hearing individuals in the US",
    },
    {
      label: "Market Size",
      value: "$1.2B",
      description: "Annual tax preparation services for the deaf community",
    },
    {
      label: "Growth Rate",
      value: "18%",
      description: "Annual growth in accessible financial services",
    },
    {
      label: "Competitor Pricing",
      value: "$250-500",
      description: "Average cost of tax preparation with accessibility features",
    },
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <TrendingUp className="h-6 w-6 text-primary" />
            Investor Dashboard
          </DialogTitle>
          <DialogDescription>
            Funding overview and investment opportunities for the Deaf-First Tax AI Platform
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="overview" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="milestones">Milestones</TabsTrigger>
            <TabsTrigger value="market">Market Analysis</TabsTrigger>
            <TabsTrigger value="ai-analysis">AI Analysis</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Funding Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-center">
                    <DollarSign className="h-6 w-6 text-primary" />
                    {(fundingStats.raised / 1000000).toFixed(1)}M
                    <span className="text-sm text-muted-foreground font-normal ml-2">
                      of ${(fundingStats.goal / 1000000).toFixed(1)}M goal
                    </span>
                  </div>
                  <Progress value={(fundingStats.raised / fundingStats.goal) * 100} className="h-2 mt-2" />
                  <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                    <span>42% Funded</span>
                    <span>Next milestone: {fundingStats.nextMilestone}</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Investors</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-center">
                    <Users className="h-6 w-6 text-primary" />
                    {fundingStats.investors}
                    <Badge variant="outline" className="ml-2">
                      Active
                    </Badge>
                  </div>
                  <div className="mt-2 space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>Min. Investment</span>
                      <span className="font-medium">${fundingStats.minInvestment.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Equity Offered</span>
                      <span className="font-medium">
                        {fundingStats.equity}% per ${fundingStats.minInvestment.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Valuation</span>
                      <span className="font-medium">${(fundingStats.valuation / 1000000).toFixed(1)}M</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Project Completion</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold flex items-center">
                    <BarChart3 className="h-6 w-6 text-primary" />
                    {fundingStats.completionPercentage}%
                  </div>
                  <Progress value={fundingStats.completionPercentage} className="h-2 mt-2" />
                  <div className="mt-4 space-y-2">
                    {milestones.slice(0, 3).map((milestone) => (
                      <div key={milestone.name} className="flex items-center gap-2 text-sm">
                        {milestone.status === "completed" ? (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        ) : milestone.status === "in-progress" ? (
                          <Clock className="h-4 w-4 text-amber-500" />
                        ) : (
                          <div className="h-4 w-4 rounded-full border border-muted-foreground" />
                        )}
                        <span>{milestone.name}</span>
                        <span className="text-muted-foreground ml-auto">{milestone.date}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Investment Opportunity</CardTitle>
                <CardDescription>
                  Join us in building the first AI-powered tax platform designed specifically for the deaf community
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-medium">Problem</h4>
                    <p className="text-sm text-muted-foreground">
                      The deaf community faces significant barriers in accessing tax services, with limited sign
                      language support and accessibility features in existing platforms.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Solution</h4>
                    <p className="text-sm text-muted-foreground">
                      Our platform provides AI-powered tax preparation with built-in sign language support, visual
                      explanations, and a network of deaf-friendly tax advisors.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h4 className="font-medium">Market Opportunity</h4>
                    <p className="text-sm text-muted-foreground">
                      With 11.5M deaf and hard of hearing individuals in the US and a $1.2B market for accessible tax
                      services, we're targeting an underserved but significant market.
                    </p>
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-2">Use of Funds</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <div className="text-sm text-muted-foreground">Product Development</div>
                      <div className="font-medium">45%</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Marketing & Acquisition</div>
                      <div className="font-medium">25%</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Operations</div>
                      <div className="font-medium">20%</div>
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground">Legal & Compliance</div>
                      <div className="font-medium">10%</div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col sm:flex-row gap-4 items-center justify-between">
                <div className="text-sm text-muted-foreground">
                  Minimum investment: ${fundingStats.minInvestment.toLocaleString()} for {fundingStats.equity}% equity
                </div>
                <div className="flex gap-2">
                  <Button variant="outline">Request Pitch Deck</Button>
                  <Button>Invest Now</Button>
                </div>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="milestones" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Development Roadmap</CardTitle>
                <CardDescription>
                  Our progress and upcoming milestones for the Deaf-First Tax AI Platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative">
                  <div className="absolute left-9 top-0 bottom-0 w-px bg-border" />
                  <div className="space-y-8">
                    {milestones.map((milestone, index) => (
                      <div key={milestone.name} className="relative flex gap-6">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center z-10 ${
                            milestone.status === "completed"
                              ? "bg-green-100 text-green-600"
                              : milestone.status === "in-progress"
                                ? "bg-amber-100 text-amber-600"
                                : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {milestone.status === "completed" ? (
                            <CheckCircle className="h-5 w-5" />
                          ) : milestone.status === "in-progress" ? (
                            <Clock className="h-5 w-5" />
                          ) : (
                            <Calendar className="h-5 w-5" />
                          )}
                        </div>
                        <div className="flex-1 pt-1">
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">{milestone.name}</h4>
                            <Badge
                              variant={
                                milestone.status === "completed"
                                  ? "default"
                                  : milestone.status === "in-progress"
                                    ? "secondary"
                                    : "outline"
                              }
                            >
                              {milestone.status === "completed"
                                ? "Completed"
                                : milestone.status === "in-progress"
                                  ? "In Progress"
                                  : "Upcoming"}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{milestone.date}</p>
                          <div className="mt-3">
                            <p className="text-sm">
                              {index === 0 &&
                                "Initial concept design and market research completed. User interviews with deaf community members conducted."}
                              {index === 1 &&
                                "Alpha version developed with core accessibility features. Limited testing with focus group."}
                              {index === 2 &&
                                "Beta version with full feature set currently in development. Recruiting beta testers from deaf community."}
                              {index === 3 &&
                                "Public release planned with marketing campaign targeting deaf community organizations."}
                              {index === 4 &&
                                "Expansion to additional markets and languages planned after initial launch success."}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Current Sprint Focus</CardTitle>
                <CardDescription>Key features being developed in the current development cycle</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-green-500" />
                      <span className="font-medium">Three.js Tax Visualizations</span>
                    </div>
                    <Badge>80% Complete</Badge>
                  </div>
                  <Progress value={80} className="h-2" />

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-amber-500" />
                      <span className="font-medium">Video Interpreter Integration</span>
                    </div>
                    <Badge variant="secondary">60% Complete</Badge>
                  </div>
                  <Progress value={60} className="h-2" />

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-blue-500" />
                      <span className="font-medium">Advisor Matching Algorithm</span>
                    </div>
                    <Badge variant="secondary">45% Complete</Badge>
                  </div>
                  <Progress value={45} className="h-2" />

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-red-500" />
                      <span className="font-medium">API Integration Framework</span>
                    </div>
                    <Badge variant="outline">25% Complete</Badge>
                  </div>
                  <Progress value={25} className="h-2" />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="market" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Market Analysis</CardTitle>
                <CardDescription>
                  Key statistics and market opportunity for the Deaf-First Tax AI Platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-medium text-lg mb-4">Market Statistics</h3>
                    <div className="space-y-6">
                      {marketStats.map((stat) => (
                        <div key={stat.label}>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-muted-foreground">{stat.label}</span>
                            <span className="font-bold text-xl">{stat.value}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">{stat.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="font-medium text-lg mb-4">Competitive Landscape</h3>
                    <div className="space-y-4">
                      <div className="border rounded-md p-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">Traditional Tax Services</h4>
                          <Badge variant="outline">Low Accessibility</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          H&R Block, TurboTax, and other major providers offer limited accessibility features and rarely
                          provide sign language support.
                        </p>
                      </div>

                      <div className="border rounded-md p-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">Specialized Accountants</h4>
                          <Badge variant="outline">High Cost</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Some accountants specialize in working with deaf clients but charge premium rates and have
                          limited availability.
                        </p>
                      </div>

                      <div className="border rounded-md p-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">Non-Profit Services</h4>
                          <Badge variant="outline">Limited Scope</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Non-profit organizations offer free tax help but have limited capacity and typically only
                          handle basic tax situations.
                        </p>
                      </div>

                      <div className="border rounded-md p-3 bg-primary/5 border-primary/20">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">Deaf-First Tax AI Platform</h4>
                          <Badge>Our Solution</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Combines AI-powered tax preparation with built-in accessibility features at a competitive
                          price point with unlimited availability.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <h3 className="font-medium text-lg mb-4">Growth Projections</h3>
                  <div className="h-[300px] bg-muted rounded-md flex items-center justify-center">
                    <p className="text-muted-foreground">Interactive growth chart will appear here</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="ai-analysis">
            <InvestmentAIAnalysis />
          </TabsContent>
        </Tabs>

        <div className="flex justify-between mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button onClick={() => window.open("/investors", "_blank")}>
            Full Investor Portal <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
