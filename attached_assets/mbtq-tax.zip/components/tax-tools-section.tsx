import { BarChart3, Calculator, FileText, Search, Briefcase, ArrowRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export function TaxToolsSection() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container">
        <div className="flex flex-col md:flex-row items-start justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
              Powered by <span className="text-primary">Bloomberg Tax</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              Our platform integrates with Bloomberg Tax's suite of tools to provide you with accurate, efficient, and
              time-saving tax solutions.
            </p>
          </div>
          <div className="flex items-center">
            <Image
              src="/placeholder.svg?height=50&width=200"
              alt="Bloomberg Tax Logo"
              width={200}
              height={50}
              className="h-10 w-auto"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Card>
            <CardHeader>
              <div className="mb-3">
                <Search className="h-10 w-10 text-primary" />
              </div>
              <CardTitle>Top Research Tools</CardTitle>
              <CardDescription>
                Stay on top of changes in federal, state, and international tax with expert analysis.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>Tax Management Portfolios</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>Federal, State & International Tax Updates</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>Expert Analysis & Commentary</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full" asChild>
                <Link href="/research">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <div className="mb-3">
                <Calculator className="h-10 w-10 text-primary" />
              </div>
              <CardTitle>Tax Planning Software</CardTitle>
              <CardDescription>Help clients grow and preserve wealth with our powerful planning tools.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>20-Year Tax Projections</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>Side-by-Side Scenario Comparisons</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>Seamless Data Import</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full" asChild>
                <Link href="/planning">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <div className="mb-3">
                <BarChart3 className="h-10 w-10 text-primary" />
              </div>
              <CardTitle>Smarter Automation</CardTitle>
              <CardDescription>Create more efficient workflows and remove risk from your process.</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>AI-Powered Tax Answers</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>Automated Workpapers</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                  <span>Accurate Provision Calculations</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" className="w-full" asChild>
                <Link href="/automation">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>

        <div className="mt-16">
          <h3 className="text-2xl font-bold text-center mb-8">Tools Designed for Every Tax Professional</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="mb-3">
                  <Briefcase className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>Tax Partner</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Grow your firm client base and revenue with timely, strategic insights and technology designed to
                  streamline the most complex planning and compliance scenarios.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Client Growth Strategies</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Complex Planning Tools</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Revenue Optimization</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-3">
                  <FileText className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>Tax Manager</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Easily prepare and file corporate, partnership, and individual tax returns with our integrated
                  solutions.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Streamlined Return Preparation</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Team Collaboration Tools</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Compliance Management</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-3">
                  <Calculator className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>CPA</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Save time on tax planning, business modeling, budgeting, and reporting with integrated news, analysis,
                  and innovative technology.
                </p>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Quick Calculations</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Optimal Tax Positioning</span>
                  </li>
                  <li className="flex items-start">
                    <div className="mr-2 mt-0.5 h-2 w-2 rounded-full bg-primary" />
                    <span>Time-Saving Automation</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
