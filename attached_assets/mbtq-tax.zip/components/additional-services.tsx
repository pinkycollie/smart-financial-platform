import { Shield, Wand2 } from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export function AdditionalServices() {
  return (
    <section className="py-20">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Additional Services</h2>
          <p className="mt-4 text-muted-foreground max-w-3xl mx-auto">
            Beyond tax solutions, we offer complementary services to meet all your financial and business needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
            <CardHeader>
              <div className="mb-3">
                <Shield className="h-10 w-10 text-primary" />
              </div>
              <CardTitle>MBTQ Insurance</CardTitle>
              <CardDescription>Specialized insurance solutions for the MBTQ community</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Our insurance offerings are designed with the unique needs of the MBTQ community in mind, providing
                coverage that truly understands and protects you.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Health insurance with inclusive coverage</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Life and disability policies that recognize all families</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Business insurance for MBTQ-owned enterprises</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Accessible claims process with support in multiple formats</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button asChild className="w-full">
                <Link href="/insurance">Learn More About MBTQ Insurance</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="bg-gradient-to-br from-secondary/10 to-secondary/20 border-secondary/20">
            <CardHeader>
              <div className="mb-3">
                <Wand2 className="h-10 w-10 text-primary" />
              </div>
              <CardTitle>360 Magicians</CardTitle>
              <CardDescription>Comprehensive business solutions that work like magic</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Our 360 Magicians service provides end-to-end business solutions that seamlessly integrate with your tax
                planning for holistic financial management.
              </p>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Business formation and compliance</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Bookkeeping and financial reporting</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Strategic business consulting</span>
                </li>
                <li className="flex items-start">
                  <div className="mr-2 mt-1 h-2 w-2 rounded-full bg-primary" />
                  <span>Technology implementation and support</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button asChild variant="secondary" className="w-full">
                <Link href="/360-magicians">Discover 360 Magicians</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </section>
  )
}
