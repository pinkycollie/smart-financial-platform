"use client"

import { createContext, useContext, useState, type ReactNode } from "react"
import { useAccessibility } from "./accessibility-provider"
import { Alert } from "@/components/ui/alert"
import { X } from "lucide-react"

type AlertType = "info" | "success" | "warning" | "error"

type VisualAlert = {
  id: string
  message: string
  type: AlertType
  duration?: number
}

type VisualAlertContextType = {
  alerts: VisualAlert[]
  showAlert: (message: string, type: AlertType, duration?: number) => void
  dismissAlert: (id: string) => void
}

const VisualAlertContext = createContext<VisualAlertContextType | undefined>(undefined)

export function VisualAlertProvider({ children }: { children: ReactNode }) {
  const [alerts, setAlerts] = useState<VisualAlert[]>([])
  const { preferences } = useAccessibility()

  const showAlert = (message: string, type: AlertType = "info", duration = 5000) => {
    const id = Math.random().toString(36).substring(2, 9)
    const newAlert = { id, message, type, duration }

    setAlerts((prev) => [...prev, newAlert])

    if (duration > 0) {
      setTimeout(() => {
        dismissAlert(id)
      }, duration)
    }

    // If visual alerts are enabled, flash the screen
    if (preferences.visualAlerts) {
      const flashElement = document.createElement("div")
      flashElement.className = `fixed inset-0 z-50 bg-${type}-500 bg-opacity-30 pointer-events-none`
      document.body.appendChild(flashElement)

      setTimeout(() => {
        flashElement.classList.add("opacity-0", "transition-opacity", "duration-500")
        setTimeout(() => {
          document.body.removeChild(flashElement)
        }, 500)
      }, 100)
    }
  }

  const dismissAlert = (id: string) => {
    setAlerts((prev) => prev.filter((alert) => alert.id !== id))
  }

  return (
    <VisualAlertContext.Provider value={{ alerts, showAlert, dismissAlert }}>
      {children}

      {/* Visual Alert Container */}
      {alerts.length > 0 && (
        <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-md">
          {alerts.map((alert) => (
            <Alert key={alert.id} variant={alert.type} className="animate-slide-in-right">
              <div className="flex justify-between items-center">
                <span>{alert.message}</span>
                <button onClick={() => dismissAlert(alert.id)} className="ml-2">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </Alert>
          ))}
        </div>
      )}
    </VisualAlertContext.Provider>
  )
}

export function useVisualAlert() {
  const context = useContext(VisualAlertContext)
  if (context === undefined) {
    throw new Error("useVisualAlert must be used within a VisualAlertProvider")
  }
  return context
}
