"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type AccessibilityPreferences = {
  highContrast: boolean
  largeText: boolean
  visualAlerts: boolean
  captionsEnabled: boolean
  signLanguagePreferred: boolean
  preferredSignLanguage: "ASL" | "BSL" | "Other"
  reduceMotion: boolean
}

type AccessibilityContextType = {
  preferences: AccessibilityPreferences
  updatePreference: <K extends keyof AccessibilityPreferences>(key: K, value: AccessibilityPreferences[K]) => void
  resetPreferences: () => void
}

const defaultPreferences: AccessibilityPreferences = {
  highContrast: false,
  largeText: false,
  visualAlerts: true,
  captionsEnabled: true,
  signLanguagePreferred: true,
  preferredSignLanguage: "ASL",
  reduceMotion: false,
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined)

export function AccessibilityProvider({ children }: { children: ReactNode }) {
  const [preferences, setPreferences] = useState<AccessibilityPreferences>(defaultPreferences)

  // Load preferences from localStorage on mount
  useEffect(() => {
    const savedPreferences = localStorage.getItem("accessibility-preferences")
    if (savedPreferences) {
      try {
        setPreferences(JSON.parse(savedPreferences))
      } catch (e) {
        console.error("Failed to parse saved accessibility preferences", e)
      }
    }
  }, [])

  // Save preferences to localStorage when they change
  useEffect(() => {
    localStorage.setItem("accessibility-preferences", JSON.stringify(preferences))

    // Apply preferences to document
    document.documentElement.classList.toggle("high-contrast", preferences.highContrast)
    document.documentElement.classList.toggle("large-text", preferences.largeText)
    document.documentElement.classList.toggle("reduce-motion", preferences.reduceMotion)
  }, [preferences])

  const updatePreference = <K extends keyof AccessibilityPreferences>(key: K, value: AccessibilityPreferences[K]) => {
    setPreferences((prev) => ({ ...prev, [key]: value }))
  }

  const resetPreferences = () => {
    setPreferences(defaultPreferences)
  }

  return (
    <AccessibilityContext.Provider value={{ preferences, updatePreference, resetPreferences }}>
      {children}
    </AccessibilityContext.Provider>
  )
}

export function useAccessibility() {
  const context = useContext(AccessibilityContext)
  if (context === undefined) {
    throw new Error("useAccessibility must be used within an AccessibilityProvider")
  }
  return context
}
