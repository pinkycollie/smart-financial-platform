import { CheckCircle2 } from "lucide-react"

export function BloombergTaxSection() {
  return (
    <section className="py-20 bg-background">
      <div className="container">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2">
            <div className="inline-flex items-center rounded-full border px-4 py-1 text-sm mb-4">
              <span className="font-medium">Powered by Bloomberg Tax</span>
            </div>
            <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Best-in-Class Tax Tools for Your Success</h2>
            <p className="mt-4 text-muted-foreground">
              MBTQ Tax leverages Bloomberg Tax's industry-leading research and technology solutions to provide accurate,
              efficient, and timely tax services.
            </p>

            <div className="mt-8 space-y-4">
              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-primary/10 p-1">
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Always Be Accurate</h3>
                  <p className="text-sm text-muted-foreground">
                    Know you're accurate every time with technology that minimizes manual risks and gives you practical
                    insight on how to best apply tax law.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-primary/10 p-1">
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Gain Efficiency</h3>
                  <p className="text-sm text-muted-foreground">
                    Automate repetitive processes, streamline client work, and have confidence in your calculations with
                    tools that are purpose-built for tax.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="mt-1 rounded-full bg-primary/10 p-1">
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">Save Time</h3>
                  <p className="text-sm text-muted-foreground">
                    Because our reliable research and user-friendly software supports a more manageable workload, you'll
                    have time to focus on providing strategic guidance.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="md:w-1/2">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg border bg-card p-4 shadow-sm">
                <h3 className="font-medium mb-2">Tax Research</h3>
                <p className="text-xs text-muted-foreground">
                  Stay on top of changes in federal, state, and international tax with expert analysis.
                </p>
              </div>

              <div className="rounded-lg border bg-card p-4 shadow-sm">
                <h3 className="font-medium mb-2">Depreciation Modeling</h3>
                <p className="text-xs text-muted-foreground">
                  Cloud-based Fixed Assets solution with seamless integration and secure data access.
                </p>
              </div>

              <div className="rounded-lg border bg-card p-4 shadow-sm">
                <h3 className="font-medium mb-2">Tax Planning</h3>
                <p className="text-xs text-muted-foreground">
                  Income Tax Planner with projections up to 20 years and side-by-side comparisons.
                </p>
              </div>

              <div className="rounded-lg border bg-card p-4 shadow-sm">
                <h3 className="font-medium mb-2">Provision Calculations</h3>
                <p className="text-xs text-muted-foreground">
                  Simplified ASC 740 compliance with Bloomberg Tax Provision.
                </p>
              </div>
            </div>

            <div className="mt-4 rounded-lg border bg-muted p-4 text-center">
              <p className="text-sm font-medium">
                All Bloomberg Tax tools are available at a discounted rate through MBTQ Tax
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
