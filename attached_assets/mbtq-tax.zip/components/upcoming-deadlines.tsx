import { CalendarClock } from "lucide-react"

export function UpcomingDeadlines() {
  return (
    <div className="space-y-4">
      {deadlines.map((deadline, index) => (
        <div key={index} className="flex items-start gap-4 rounded-lg border p-3">
          <div className={`mt-1 rounded-full p-1 ${getPriorityColor(deadline.priority)}`}>
            <CalendarClock className="h-4 w-4 text-white" />
          </div>
          <div className="flex-1 space-y-1">
            <p className="text-sm font-medium leading-none">{deadline.title}</p>
            <p className="text-xs text-muted-foreground">{deadline.client}</p>
            <p className="text-xs font-medium">{deadline.date}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

function getPriorityColor(priority: string) {
  switch (priority) {
    case "high":
      return "bg-red-500"
    case "medium":
      return "bg-orange-500"
    case "low":
      return "bg-green-500"
    default:
      return "bg-blue-500"
  }
}

const deadlines = [
  {
    title: "Quarterly Tax Filing",
    client: "Rainbow Enterprises LLC",
    date: "Due in 5 days",
    priority: "high",
  },
  {
    title: "Annual Return",
    client: "Deaf Community Center",
    date: "Due in 2 weeks",
    priority: "medium",
  },
  {
    title: "Extension Filing",
    client: "Accessibility Partners Inc.",
    date: "Due in 3 weeks",
    priority: "low",
  },
  {
    title: "Tax Planning Session",
    client: "Trans Health Coalition",
    date: "Scheduled in 1 week",
    priority: "medium",
  },
]
