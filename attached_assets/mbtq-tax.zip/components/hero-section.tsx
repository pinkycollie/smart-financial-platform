import Image from "next/image"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"

export function HeroSection() {
  return (
    <section className="relative py-20 md:py-32 overflow-hidden">
      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mbtqtaxlogo.jpg-ZhKwAyivF5WW6WaO3UvnS3wUHTxjat.jpeg"
                alt="MBTQ Tax Logo"
                width={48}
                height={48}
                className="h-12 w-auto"
              />
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
                MBTQ <span className="text-primary">Tax</span>
              </h1>
            </div>
            <p className="text-3xl font-semibold tracking-tight">Tax Solutions for the MBTQ Community</p>
            <p className="mt-6 text-xl text-muted-foreground max-w-2xl">
              A comprehensive tax platform designed specifically for the unique needs of the MBTQ community, with
              accessibility at its core.
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild>
                <Link href="/signup">
                  Get Started <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="#features">Learn More</Link>
              </Button>
            </div>
          </div>
          <div className="relative">
            <div className="relative h-[400px] w-full rounded-lg overflow-hidden shadow-xl">
              <div className="absolute inset-0 bg-gradient-to-br from-primary/30 to-primary/10"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mbtqtaxlogo.jpg-ZhKwAyivF5WW6WaO3UvnS3wUHTxjat.jpeg"
                  alt="MBTQ Tax Logo"
                  width={150}
                  height={150}
                  className="h-32 w-auto"
                />
              </div>
              <div className="absolute inset-0 flex items-end justify-center pb-12">
                <p className="text-2xl font-bold text-center">
                  Inclusive Tax Solutions
                  <br />
                  for Everyone
                </p>
              </div>
            </div>
            <div className="absolute -bottom-6 -left-6 bg-primary/10 backdrop-blur-sm border border-primary/20 p-4 rounded-lg shadow-lg">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                  <span className="text-primary font-bold">95%</span>
                </div>
                <div>
                  <p className="font-medium">User Satisfaction</p>
                  <p className="text-sm text-muted-foreground">Based on 1,000+ reviews</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-primary/20 via-background to-background"></div>
    </section>
  )
}
