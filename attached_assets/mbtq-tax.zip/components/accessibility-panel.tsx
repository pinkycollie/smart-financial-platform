"use client"

import { useState } from "react"
import { Accessibility, Eye, Volume2, Keyboard } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"

export function AccessibilityPanel() {
  const [fontSize, setFontSize] = useState(100)

  return (
    <section className="py-20 bg-background">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">Accessibility Features</h2>
          <p className="mt-4 text-muted-foreground max-w-3xl mx-auto">
            Our platform is designed to be accessible to everyone, with features that can be customized to meet your
            specific needs.
          </p>
        </div>

        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Accessibility className="h-6 w-6 text-primary" />
              Accessibility Controls
            </CardTitle>
            <CardDescription>Customize your experience with these accessibility options</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="visual">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="visual" className="flex items-center gap-2">
                  <Eye className="h-4 w-4" /> Visual
                </TabsTrigger>
                <TabsTrigger value="audio" className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4" /> Audio
                </TabsTrigger>
                <TabsTrigger value="input" className="flex items-center gap-2">
                  <Keyboard className="h-4 w-4" /> Input
                </TabsTrigger>
              </TabsList>

              <TabsContent value="visual" className="space-y-6 pt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="font-size">Font Size ({fontSize}%)</Label>
                    <div className="w-2/3">
                      <Slider
                        id="font-size"
                        defaultValue={[100]}
                        min={75}
                        max={200}
                        step={25}
                        onValueChange={(value) => setFontSize(value[0])}
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="high-contrast">High Contrast</Label>
                    <Switch id="high-contrast" />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="reduce-motion">Reduce Motion</Label>
                    <Switch id="reduce-motion" />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="dyslexia-font">Dyslexia-friendly Font</Label>
                    <Switch id="dyslexia-font" />
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <p
                    className={cn(
                      "text-base",
                      fontSize && {
                        "text-sm": fontSize === 75,
                        "text-base": fontSize === 100,
                        "text-lg": fontSize === 125,
                        "text-xl": fontSize === 150,
                        "text-2xl": fontSize === 175,
                        "text-3xl": fontSize === 200,
                      },
                    )}
                  >
                    This is a preview of how text will appear with your current settings.
                  </p>
                </div>
              </TabsContent>

              <TabsContent value="audio" className="space-y-6 pt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="screen-reader">Screen Reader Compatible</Label>
                    <Switch id="screen-reader" defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="captions">Always Show Captions</Label>
                    <Switch id="captions" />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="audio-descriptions">Audio Descriptions</Label>
                    <Switch id="audio-descriptions" />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="input" className="space-y-6 pt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="keyboard-navigation">Enhanced Keyboard Navigation</Label>
                    <Switch id="keyboard-navigation" defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="voice-commands">Voice Commands</Label>
                    <Switch id="voice-commands" />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="sticky-keys">Sticky Keys</Label>
                    <Switch id="sticky-keys" />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-8 flex justify-end">
              <Button>Save Preferences</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
