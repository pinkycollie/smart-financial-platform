"use client"

import { useRef, useEffect, useState } from "react"
import * as THREE from "three"
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls"
import { useAccessibility } from "@/components/accessibility/accessibility-provider"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface TaxCategory {
  name: string
  amount: number
  color: string
}

interface TaxBreakdown3DProps {
  data: TaxCategory[]
  title: string
  description?: string
}

export function TaxBreakdown3D({ data, title, description }: TaxBreakdown3DProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [activeCategory, setActiveCategory] = useState<string | null>(null)
  const { preferences } = useAccessibility()
  const [viewMode, setViewMode] = useState<"3d" | "2d">("3d")

  useEffect(() => {
    if (!containerRef.current || viewMode !== "3d") return

    // Setup scene
    const scene = new THREE.Scene()
    scene.background = new THREE.Color(0xf8f9fa)

    // Setup camera
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000,
    )
    camera.position.z = 5

    // Setup renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true })
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
    containerRef.current.appendChild(renderer.domElement)

    // Setup controls
    const controls = new OrbitControls(camera, renderer.domElement)
    controls.enableDamping = true
    controls.dampingFactor = 0.05

    // Reduce motion if accessibility preference is set
    if (preferences.reduceMotion) {
      controls.enableRotate = false
      controls.enableZoom = false
      controls.enablePan = false
    }

    // Create 3D visualization
    const totalAmount = data.reduce((sum, category) => sum + category.amount, 0)
    const objects: THREE.Mesh[] = []

    // Create a circular arrangement of 3D bars
    const radius = 2
    data.forEach((category, index) => {
      const angle = (index / data.length) * Math.PI * 2
      const height = (category.amount / totalAmount) * 2 + 0.5 // Scale height based on amount

      // Create bar geometry
      const geometry = new THREE.BoxGeometry(0.5, height, 0.5)
      const material = new THREE.MeshStandardMaterial({
        color: new THREE.Color(category.color),
        roughness: 0.7,
        metalness: 0.2,
      })

      const bar = new THREE.Mesh(geometry, material)
      bar.position.set(Math.cos(angle) * radius, height / 2, Math.sin(angle) * radius)
      bar.userData = { category: category.name }

      scene.add(bar)
      objects.push(bar)

      // Add text label
      const canvas = document.createElement("canvas")
      const context = canvas.getContext("2d")
      if (context) {
        canvas.width = 256
        canvas.height = 128
        context.fillStyle = "#ffffff"
        context.fillRect(0, 0, canvas.width, canvas.height)
        context.font = "bold 24px Arial"
        context.fillStyle = "#000000"
        context.textAlign = "center"
        context.fillText(category.name, canvas.width / 2, 40)
        context.font = "18px Arial"
        context.fillText(`$${category.amount.toLocaleString()}`, canvas.width / 2, 70)

        const texture = new THREE.CanvasTexture(canvas)
        const labelMaterial = new THREE.SpriteMaterial({ map: texture })
        const label = new THREE.Sprite(labelMaterial)
        label.position.set(Math.cos(angle) * (radius + 0.3), height + 0.5, Math.sin(angle) * (radius + 0.3))
        label.scale.set(1, 0.5, 1)
        scene.add(label)
      }
    })

    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6)
    scene.add(ambientLight)

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8)
    directionalLight.position.set(5, 10, 7)
    scene.add(directionalLight)

    // Add ground plane
    const groundGeometry = new THREE.CircleGeometry(radius + 1, 32)
    const groundMaterial = new THREE.MeshStandardMaterial({
      color: 0xeeeeee,
      roughness: 0.9,
      metalness: 0.1,
    })
    const ground = new THREE.Mesh(groundGeometry, groundMaterial)
    ground.rotation.x = -Math.PI / 2
    scene.add(ground)

    // Raycaster for interaction
    const raycaster = new THREE.Raycaster()
    const mouse = new THREE.Vector2()

    function onMouseMove(event: MouseEvent) {
      const rect = renderer.domElement.getBoundingClientRect()
      mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1
      mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1

      raycaster.setFromCamera(mouse, camera)
      const intersects = raycaster.intersectObjects(objects)

      if (intersects.length > 0) {
        const category = intersects[0].object.userData.category
        setActiveCategory(category)
        document.body.style.cursor = "pointer"
      } else {
        setActiveCategory(null)
        document.body.style.cursor = "default"
      }
    }

    renderer.domElement.addEventListener("mousemove", onMouseMove)

    // Animation loop
    function animate() {
      requestAnimationFrame(animate)
      controls.update()
      renderer.render(scene, camera)
    }
    animate()

    // Handle window resize
    function handleResize() {
      if (!containerRef.current) return

      camera.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight
      camera.updateProjectionMatrix()
      renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight)
    }

    window.addEventListener("resize", handleResize)

    // Cleanup
    return () => {
      if (containerRef.current && containerRef.current.contains(renderer.domElement)) {
        containerRef.current.removeChild(renderer.domElement)
      }
      renderer.domElement.removeEventListener("mousemove", onMouseMove)
      window.removeEventListener("resize", handleResize)
    }
  }, [data, preferences.reduceMotion, viewMode])

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
        <Tabs defaultValue="3d" onValueChange={(value) => setViewMode(value as "3d" | "2d")}>
          <TabsList>
            <TabsTrigger value="3d">3D View</TabsTrigger>
            <TabsTrigger value="2d">2D View</TabsTrigger>
          </TabsList>
        </Tabs>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <div
            ref={containerRef}
            className="w-full h-[400px] rounded-md overflow-hidden"
            aria-label="Interactive 3D tax breakdown visualization"
          />

          {activeCategory && (
            <div className="absolute bottom-4 left-4 bg-white p-3 rounded-md shadow-md">
              <p className="font-medium">{activeCategory}</p>
              <p className="text-sm text-muted-foreground">
                ${data.find((c) => c.name === activeCategory)?.amount.toLocaleString()}
              </p>
            </div>
          )}

          {viewMode === "2d" && (
            <div className="w-full h-[400px] flex items-center justify-center">
              <div className="w-full max-w-md">
                {data.map((category) => (
                  <div key={category.name} className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span>{category.name}</span>
                      <span>${category.amount.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${(category.amount / data.reduce((sum, c) => sum + c.amount, 0)) * 100}%`,
                          backgroundColor: category.color,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="mt-4 flex justify-center">
          <Button variant="outline" size="sm">
            Download as PDF
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
