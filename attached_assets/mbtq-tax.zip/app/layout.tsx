import type { ReactNode } from "react"
import { Mona_Sans as FontSans } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import { AccessibilityProvider } from "@/components/accessibility/accessibility-provider"
import { VisualAlertProvider } from "@/components/accessibility/visual-alert-provider"
import { Sidebar, SidebarProvider } from "@/components/ui/sidebar"
import { Header } from "@/components/layout/header"
import { Footer } from "@/components/layout/footer"
import { InvestorFloatingButton } from "@/components/investors/investor-floating-button"

import "@/styles/globals.css"

const fontSans = FontSans({
  subsets: ["latin"],
  variable: "--font-sans",
})

export const metadata = {
  title: "Deaf-First Tax AI Platform",
  description: "AI-powered tax preparation and planning platform designed for the deaf community",
    generator: 'v0.dev'
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head />
      <body className={`font-sans ${fontSans.variable}`}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
          <AccessibilityProvider>
            <VisualAlertProvider>
              <SidebarProvider>
                <div className="flex min-h-screen flex-col">
                  <Header />
                  <div className="flex flex-1">
                    <Sidebar />
                    <main className="flex-1 overflow-auto p-6">{children}</main>
                  </div>
                  <Footer />
                  <InvestorFloatingButton />
                </div>
              </SidebarProvider>
            </VisualAlertProvider>
          </AccessibilityProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}


import './globals.css'