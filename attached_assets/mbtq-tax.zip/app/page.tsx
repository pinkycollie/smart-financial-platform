import Link from "next/link"
import Image from "next/image"
import { ArrowRight, CheckCircle2, Shield, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { HeroSection } from "@/components/hero-section"
import { FeatureCard } from "@/components/feature-card"
import { TestimonialCard } from "@/components/testimonial-card"
import { PricingCard } from "@/components/pricing-card"
import { AccessibilityPanel } from "@/components/accessibility-panel"
import { DashboardPreview } from "@/components/dashboard-preview"
import { TaxToolsSection } from "@/components/tax-tools-section"
import { AdditionalServices } from "@/components/additional-services"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mbtqtaxlogo.jpg-ZhKwAyivF5WW6WaO3UvnS3wUHTxjat.jpeg"
              alt="MBTQ Tax Logo"
              width={32}
              height={32}
              className="h-8 w-auto"
            />
            <span className="text-xl font-bold">MBTQ Tax</span>
          </div>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="#features" className="text-sm font-medium hover:underline">
              Features
            </Link>
            <Link href="#tools" className="text-sm font-medium hover:underline">
              Tax Tools
            </Link>
            <Link href="#pricing" className="text-sm font-medium hover:underline">
              Pricing
            </Link>
            <Link href="#testimonials" className="text-sm font-medium hover:underline">
              Testimonials
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <ModeToggle />
            <Button asChild>
              <Link href="/signup">Get Started</Link>
            </Button>
          </div>
        </div>
      </header>
      <main className="flex-1">
        <HeroSection />

        <section id="features" className="py-20 bg-muted/50">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                Designed for the MBTQ Community
              </h2>
              <p className="mt-4 text-muted-foreground max-w-3xl mx-auto">
                Our platform provides a user-friendly and accessible experience with features tailored to the unique
                needs of the MBTQ community.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard
                icon={<Users className="h-10 w-10 text-primary" />}
                title="Inclusive Design"
                description="Toggle between different modes including LGBTQIA, Deaf and HH, and Disabilities to customize your experience."
              />
              <FeatureCard
                icon={<CheckCircle2 className="h-10 w-10 text-primary" />}
                title="Accessibility First"
                description="Screen reader compatibility, high contrast mode, keyboard navigation, and closed captions for all users."
              />
              <FeatureCard
                icon={<Shield className="h-10 w-10 text-primary" />}
                title="Secure & Private"
                description="Robust security measures including encryption, secure authentication, and regular security audits."
              />
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">User-Friendly Dashboard</h2>
              <p className="mt-4 text-muted-foreground max-w-3xl mx-auto">
                Our intuitive dashboard gives you complete control over your tax planning and filing.
              </p>
            </div>
            <DashboardPreview />
            <div className="text-center mt-8">
              <p className="text-sm font-semibold text-primary">Powered by Bloomberg Tax</p>
            </div>
          </div>
        </section>

        <AccessibilityPanel />

        <section id="tools" className="py-0">
          <TaxToolsSection />
        </section>

        <AdditionalServices />

        <section id="pricing" className="py-20 bg-muted/30">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">
                Affordable, Inclusive Pricing
              </h2>
              <p className="mt-4 text-muted-foreground max-w-3xl mx-auto">
                Choose the plan that works best for your needs with our flexible pricing options.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <PricingCard
                title="Basic"
                price="$7.99"
                originalPrice="$9.99"
                description="Perfect for individuals with simple tax needs"
                features={[
                  "Standard tax filing",
                  "Basic accessibility features",
                  "Email support",
                  "Secure data storage",
                  "Bloomberg Tax research (limited)",
                ]}
                buttonText="Get Started"
                buttonVariant="outline"
                badge="Most Affordable"
              />
              <PricingCard
                title="Professional"
                price="$16.99"
                originalPrice="$19.99"
                description="Ideal for those with more complex tax situations"
                features={[
                  "Everything in Basic",
                  "Advanced tax deductions",
                  "Priority support",
                  "Tax planning tools",
                  "Multi-year filing",
                  "Full Bloomberg Tax research",
                ]}
                buttonText="Get Started"
                buttonVariant="default"
                highlighted={true}
                badge="Most Popular"
              />
              <PricingCard
                title="Enterprise"
                price="$34.99"
                originalPrice="$39.99"
                description="For businesses and organizations"
                features={[
                  "Everything in Professional",
                  "Custom accessibility solutions",
                  "Dedicated account manager",
                  "API access",
                  "Bulk filing options",
                  "MBTQ Insurance discounts",
                  "360 Magicians integration",
                ]}
                buttonText="Contact Sales"
                buttonVariant="outline"
              />
            </div>
            <div className="text-center mt-8">
              <p className="text-sm text-muted-foreground">
                All plans include a 14-day free trial. No credit card required.
              </p>
            </div>
          </div>
        </section>

        <section id="testimonials" className="py-20">
          <div className="container">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl md:text-5xl">What Our Users Say</h2>
              <p className="mt-4 text-muted-foreground max-w-3xl mx-auto">
                Hear from members of the MBTQ community who have transformed their tax experience with our platform.
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <TestimonialCard
                quote="As a deaf individual, I've always struggled with tax software. MBTQ Tax's visual guides and captioned videos have made filing taxes so much easier for me."
                author="Jamie L."
                role="Graphic Designer"
              />
              <TestimonialCard
                quote="The LGBTQIA mode understands my unique tax situation as a transgender person. I finally feel seen by a tax platform."
                author="Alex T."
                role="Software Engineer"
              />
              <TestimonialCard
                quote="With my mobility impairment, the keyboard navigation and screen reader compatibility have been game-changers. I can finally file taxes independently."
                author="Morgan P."
                role="Educator"
              />
            </div>
          </div>
        </section>

        <section id="contact" className="py-20 bg-muted/50">
          <div className="container">
            <div className="max-w-md mx-auto text-center">
              <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Ready to Get Started?</h2>
              <p className="mt-4 text-muted-foreground">
                Join thousands of MBTQ community members who have simplified their tax experience.
              </p>
              <div className="mt-8">
                <Button size="lg" className="w-full">
                  Sign Up Now <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
              <p className="mt-4 text-sm text-muted-foreground">
                Have questions?{" "}
                <Link href="/contact" className="text-primary hover:underline">
                  Contact our support team
                </Link>
              </p>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-8 bg-muted/30">
        <div className="container">
          <div className="flex flex-col md:flex-row justify-between items-center mb-8">
            <div className="flex items-center gap-2 mb-4 md:mb-0">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Mbtqtaxlogo.jpg-ZhKwAyivF5WW6WaO3UvnS3wUHTxjat.jpeg"
                alt="MBTQ Tax Logo"
                width={24}
                height={24}
                className="h-6 w-auto"
              />
              <span className="text-lg font-bold">MBTQ Tax</span>
            </div>
            <div className="flex items-center">
              <p className="text-sm font-semibold">Powered by Bloomberg Tax</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold mb-3">Tax Solutions</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/tax-filing" className="text-sm text-muted-foreground hover:underline">
                    Tax Filing
                  </Link>
                </li>
                <li>
                  <Link href="/tax-planning" className="text-sm text-muted-foreground hover:underline">
                    Tax Planning
                  </Link>
                </li>
                <li>
                  <Link href="/research" className="text-sm text-muted-foreground hover:underline">
                    Tax Research
                  </Link>
                </li>
                <li>
                  <Link href="/automation" className="text-sm text-muted-foreground hover:underline">
                    Tax Automation
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Additional Services</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/insurance" className="text-sm text-muted-foreground hover:underline">
                    MBTQ Insurance
                  </Link>
                </li>
                <li>
                  <Link href="/360-magicians" className="text-sm text-muted-foreground hover:underline">
                    360 Magicians
                  </Link>
                </li>
                <li>
                  <Link href="/consulting" className="text-sm text-muted-foreground hover:underline">
                    Tax Consulting
                  </Link>
                </li>
                <li>
                  <Link href="/education" className="text-sm text-muted-foreground hover:underline">
                    Tax Education
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-sm text-muted-foreground hover:underline">
                    About Us
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="text-sm text-muted-foreground hover:underline">
                    Careers
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="text-sm text-muted-foreground hover:underline">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-sm text-muted-foreground hover:underline">
                    Contact
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="text-sm text-muted-foreground hover:underline">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-sm text-muted-foreground hover:underline">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/accessibility" className="text-sm text-muted-foreground hover:underline">
                    Accessibility Statement
                  </Link>
                </li>
                <li>
                  <Link href="/security" className="text-sm text-muted-foreground hover:underline">
                    Security
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t pt-8 text-center">
            <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} MBTQ Tax. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
