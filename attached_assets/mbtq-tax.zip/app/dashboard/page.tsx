"use client"

import { useState } from "react"
import { Tabs, TabsList } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { useVisualAlert } from "@/components/accessibility/visual-alert-provider"

export default function DashboardPage() {
  const { showAlert } = useVisualAlert()
  const [activeTab, setActiveTab] = useState("overview")

  // Sample tax data for 3D visualization
  const taxData = [
    { name: "Federal Income Tax", amount: 8250, color: "#4f46e5" },
    { name: "State Income Tax", amount: 3200, color: "#06b6d4" },
    { name: "Social Security", amount: 4500, color: "#8b5cf6" },
    { name: "Medicare", amount: 1800, color: "#ec4899" },
    { name: "Property Tax", amount: 3600, color: "#f59e0b" },
  ]

  // Sample form sections for video-enriched form
  const formSections = [
    {
      id: "personal-info",
      title: "Personal Information",
      description: "Basic information about you and your filing status",
      videoOverview: "https://example.com/videos/personal-info-overview.mp4",
      fields: [
        {
          id: "filing-status",
          label: "Filing Status",
          type: "select",
          required: true,
          helpText: "Select your filing status for the tax year",
          videoExplanation: "https://example.com/videos/filing-status-explanation.mp4",
          options: [
            { value: "single", label: "Single" },
            { value: "married-joint", label: "Married Filing Jointly" },
            { value: "married-separate", label: "Married Filing Separately" },
            { value: "head", label: "Head of Household" },
            { value: "qualifying-widow", label: "Qualifying Widow(er)" },
          ],
        },
        {
          id: "first-name",
          label: "First Name",
          type: "text",
          required: true,
        },
        {
          id: "last-name",
          label: "Last Name",
          type: "text",
          required: true,
        },
        {
          id: "ssn",
          label: "Social Security Number",
          type: "text",
          required: true,
          helpText: "Enter your 9-digit SSN without dashes",
          videoExplanation: "https://example.com/videos/ssn-explanation.mp4",
        },
      ],
    },
    {
      id: "income",
      title: "Income",
      description: "Information about your income sources",
      videoOverview: "https://example.com/videos/income-overview.mp4",
      fields: [
        {
          id: "wages",
          label: "Wages (W-2)",
          type: "number",
          required: true,
          helpText: "Total wages from all W-2 forms",
          videoExplanation: "https://example.com/videos/wages-explanation.mp4",
        },
        {
          id: "interest",
          label: "Interest Income",
          type: "number",
          required: false,
          helpText: "Interest from banks, investments, etc.",
        },
        {
          id: "dividends",
          label: "Dividend Income",
          type: "number",
          required: false,
          helpText: "Dividends from stocks and investments",
        },
        {
          id: "self-employment",
          label: "Self-Employment Income",
          type: "number",
          required: false,
          helpText: "Net income from self-employment",
          videoExplanation: "https://example.com/videos/self-employment-explanation.mp4",
        },
      ],
    },
  ]

  const handleFormSubmit = (data: Record<string, any>) => {
    console.log("Form submitted:", data)
    showAlert("Tax form submitted successfully!", "success")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome to your Deaf-First Tax AI Platform dashboard
          </p>
        </div>
        <Button onClick={() => showAlert("Starting new tax return...", "info")}>
          Start New Tax Return
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className\
